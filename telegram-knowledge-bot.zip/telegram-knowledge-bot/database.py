import sqlite3
from datetime import datetime

class KnowledgeDB:
    def __init__(self):
        self.init_database()
    
    def init_database(self):
        conn = sqlite3.connect('knowledge.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge (
                id INTEGER PRIMARY KEY,
                category TEXT NOT NULL,
                topic TEXT NOT NULL,
                content TEXT NOT NULL,
                source_type TEXT DEFAULT 'manual',
                source_url TEXT,
                tags TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_knowledge(self, category, topic, content, source_type='manual', source_url=None, tags=None):
        conn = sqlite3.connect('knowledge.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO knowledge (category, topic, content, source_type, source_url, tags)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (category, topic, content, source_type, source_url, tags))
        
        conn.commit()
        conn.close()
        return True
    
    def search_knowledge(self, query, category=None):
        conn = sqlite3.connect('knowledge.db')
        cursor = conn.cursor()
        
        if category:
            cursor.execute('''
                SELECT * FROM knowledge 
                WHERE category = ? AND (topic LIKE ? OR content LIKE ? OR tags LIKE ?)
                LIMIT 5
            ''', (category, f'%{query}%', f'%{query}%', f'%{query}%'))
        else:
            cursor.execute('''
                SELECT * FROM knowledge 
                WHERE topic LIKE ? OR content LIKE ? OR tags LIKE ? 
                LIMIT 5
            ''', (f'%{query}%', f'%{query}%', f'%{query}%'))
        
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_categories(self):
        conn = sqlite3.connect('knowledge.db')
        cursor = conn.cursor()
        
        cursor.execute('SELECT DISTINCT category FROM knowledge')
        categories = [row[0] for row in cursor.fetchall()]
        conn.close()
        return categories