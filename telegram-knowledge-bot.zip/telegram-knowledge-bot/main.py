from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackContext
from telegram import BotCommand
from config import BOT_TOKEN
from database import KnowledgeDB
from scraper import WebsiteScraper

# شیء دیتابیس
db = KnowledgeDB()
scraper = WebsiteScraper()

# دیکشنری برای مدیریت حالت کاربران
user_sessions = {}

# منوی اصلی
main_keyboard = ReplyKeyboardMarkup([
    ["➕ یادگیری", "❓ سوال"],
    ["🌐 یادگیری از لینک", "📚 موضوعات"],
    ["ℹ️ راهنما"]
], resize_keyboard=True)

# تعریف commands برای ربات
async def setup_commands(application):
    commands = [
        BotCommand("start", "شروع ربات"),
        BotCommand("learn", "آموزش مطلب جدید به ربات"),
        BotCommand("ask", "پرسش از ربات"),
        BotCommand("website", "آموزش از طریق لینک سایت"),
        BotCommand("categories", "نمایش موضوعات موجود"),
        BotCommand("help", "راهنمای استفاده")
    ]
    await application.bot.set_my_commands(commands)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'ready'}
    
    await update.message.re_text(
        "🤖 **به ربات دانش همه‌کاره خوش آمدید!**\n\n"
        "📋 **دستورهای سریع:**\n"
        "/learn - آموزش مطلب جدید\n"
        "/ask - پرسش از ربات\n" 
        "/website - آموزش از لینک سایت\n"
        "/categories - نمایش موضوعات\n"
        "/help - راهنمای کامل\n\n"
        "یا از دکمه‌های زیر استفاده کنید:",
        reply_markup=main_keyboard,
        parse_mode='Markdown'
    )

# اضافه کردن command های جدید
async def learn_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_category'}
    await update.message.re_text("لطفاً دسته‌بندی را وارد کنید (مثلاً: دارو، برنامه‌نویسی، تعمیرات):")

async def ask_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_query'}
    await update.message.re_text("لطفاً سوال یا کلمه کلیدی خود را وارد کنید:")

async def website_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_url'}
    await update.message.re_text("لطفاً لینک وبسایت را ارسال کنید:")

async def categories_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    categories = db.get_categories()
    if categories:
        await update.message.re_text(f"📂 **موضوعات موجود:**\n" + "\n".join(f"• {cat}" for cat in categories))
    else:
        await update.message.re_text("هنوز موضوعی اضافه نشده است!")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = """
📖 **راهنمای استفاده از ربات:**

**دستورهای سریع:**
/learn - آموزش مطلب جدید
/ask - پرسش از ربات  
/website - آموزش از لینک سایت
/categories - نمایش موضوعات
/help - این راهنما

**روش‌های یادگیری:**
➖ **یادگیری (متن):**
   • دسته‌بندی (مثلاً: دارو)
   • موضوع (مثلاً: استامینوفن)  
   • محتوا (اطلاعات کامل)

➖ **یادگیری (وبسایت):**
   • ارسال لینک سایت
   • انتخاب دسته‌بندی
   • ذخیره اتوماتیک محتوا

➖ **سوال:**
   • جستجو در همه اطلاعات
   • نمایش بهترین نتایج
    """
    await update.message.re_text(help_text, reply_markup=main_keyboard)

# هندلر اصلی پیام‌ها (همون قبلی)
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    
    # ایجاد سشن اگر وجود ندارد
    if user_id not in user_sessions:
        user_sessions[user_id] = {'mode': 'ready'}
    
    current_mode = user_sessions[user_id].get('mode', 'ready')
    
    if text == "➕ یادگیری":
        user_sessions[user_id] = {'mode': 'waiting_category'}
        await update.message.re_text("لطفاً دسته‌بندی را وارد کنید (مثلاً: دارو، برنامه‌نویسی، تعمیرات):")
    
    elif text == "❓ سوال":
        user_sessions[user_id] = {'mode': 'waiting_query'}
        await update.message.re_text("لطفاً سوال یا کلمه کلیدی خود را وارد کنید:")
    
    elif text == "🌐 یادگیری از لینک":
        user_sessions[user_id] = {'mode': 'waiting_url'}
        await update.message.re_text("لطفاً لینک وبسایت را ارسال کنید:")
    
    elif text == "📚 موضوعات":
        categories = db.get_categories()
        if categories:
            await update.message.re_text(f"📂 **موضوعات موجود:**\n" + "\n".join(f"• {cat}" for cat in categories))
        else:
            await update.message.re_text("هنوز موضوعی اضافه نشده است!")
    
    elif text == "ℹ️ راهنما":
        await help_command(update, context)
    
    # مدیریت حالت‌ها (همون کد قبلی)
    elif current_mode == 'waiting_category':
        user_sessions[user_id]['category'] = text
        user_sessions[user_id]['mode'] = 'waiting_topic'
        await update.message.re_text("عالی! حالا موضوع یا عنوان را وارد کنید:")
    
    elif current_mode == 'waiting_topic':
        user_sessions[user_id]['topic'] = text
        user_sessions[user_id]['mode'] = 'waiting_content'
        await update.message.re_text("حالا محتوا یا اطلاعات را وارد کنید:")
    
    elif current_mode == 'waiting_content':
        category = user_sessions[user_id]['category']
        topic = user_sessions[user_id]['topic']
        content = text
        
        db.save_knowledge(category, topic, content)
        user_sessions[user_id] = {'mode': 'ready'}
        
        await update.message.re_text(
            f"✅ **اطلاعات ذخیره شد!**\n\n"
            f"📁 دسته: {category}\n"
            f"📝 موضوع: {topic}\n\n"
            f"حالا می‌تونی با /ask ازم بپرسی!",
            reply_markup=main_keyboard
        )
    
    elif current_mode == 'waiting_query':
        query = text
        results = db.search_knowledge(query)
        
        if results:
            response = "🔍 **نتایج جستجو:**\n\n"
            for i, result in enumerate(results[:3], 1):
                response += f"{i}. **{result[2]}** ({result[1]})\n{result[3][:100]}...\n\n"
        else:
            response = "❌ هیچ نتیجه‌ای پیدا نشد. می‌خوای با /learn اینو بهم یاد بدی؟"
        
        await update.message.re_text(response, reply_markup=main_keyboard)
        user_sessions[user_id] = {'mode': 'ready'}
    
    elif current_mode == 'waiting_url':
        url = text
        if not url.startswith(('http://', 'https://')):
            await update.message.re_text("لطفاً یک لینک معتبر ارسال کنید (با http یا https)")
            return
        
        await update.message.re_text("⏳ در حال دریافت محتوا از سایت...")
        content = scraper.scrape_website(url)
        
        if content.startswith("خطا"):
            await update.message.re_text(content, reply_markup=main_keyboard)
            user_sessions[user_id] = {'mode': 'ready'}
            return
        
        user_sessions[user_id] = {
            'mode': 'waiting_website_category',
            'website_content': content,
            'website_url': url
        }
        
        await update.message.re_text(
            f"✅ **محتوا دریافت شد!**\n\n"
            f"📝 {content[:200]}...\n\n"
            f"لطفاً دسته‌بندی این محتوا را وارد کنید:"
        )
    
    elif current_mode == 'waiting_website_category':
        category = text
        content = user_sessions[user_id]['website_content']
        url = user_sessions[user_id]['website_url']
        
        # استخراج دامنه برای عنوان
        domain = url.split('//')[-1].split('/')[0]
        
        db.save_knowledge(
            category=category,
            topic=domain,
            content=content,
            source_type='website',
            source_url=url
        )
        
        user_sessions[user_id] = {'mode': 'ready'}
        
        await update.message.re_text(
            f"✅ **اطلاعات از سایت ذخیره شد!**\n\n"
            f"🌐 سایت: {domain}\n"
            f"📁 دسته: {category}\n\n"
            f"حالا می‌تونی با /ask در موردش سوال بپرسی!",
            reply_markup=main_keyboard
        )
    
    else:
        await update.message.re_text("لطفاً از منوی زیر یک گزینه انتخاب کنید:", reply_markup=main_keyboard)

def main():
    application = Application.builder().token(BOT_TOKEN).build()
    
    # تنظیم commands
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("learn", learn_command))
    application.add_handler(CommandHandler("ask", ask_command))
    application.add_handler(CommandHandler("website", website_command))
    application.add_handler(CommandHandler("categories", categories_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # تنظیم commands در تلگرام
    application.post_init = setup_commands
    
    print("🤖 ربات شروع به کار کرد...")
    print("📋 Commands اضافه شدند:")
    print("   /start - /learn - /ask - /website - /categories - /help")
    application.run_polling()

if __name__ == "__main__":
    main()