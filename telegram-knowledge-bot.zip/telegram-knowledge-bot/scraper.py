import requests
import re

class WebsiteScraper:
    @staticmethod
    def scrape_website(url):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            # پاکسازی ساده متن با regex (بدون نیاز به lxml)
            text = response.text
            clean_text = re.sub(r'<[^>]+>', '', text)
            clean_text = re.sub(r'\s+', ' ', clean_text)
            
            return clean_text[:4000].strip()
            
        except Exception as e:
            return f"خطا در دریافت محتوا: {str(e)}"