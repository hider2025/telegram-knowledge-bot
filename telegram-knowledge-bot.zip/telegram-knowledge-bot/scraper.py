import requests
from bs4 import BeautifulSoup
import re

class WebsiteScraper:
    @staticmethod
    def scrape_website(url):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # حذف تگ‌های غیرضروری
            for element in soup(["script", "style", "nav", "header", "footer"]):
                element.decompose()
            
            # استخراج متن
            text = soup.get_text()
            
            # پاکسازی متن
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            clean_text = ' '.join(chunk for chunk in chunks if chunk)
            
            # کوتاه کردن متن اگر خیلی طولانی باشد
            from config import MAX_CONTENT_LENGTH
            return clean_text[:MAX_CONTENT_LENGTH]
            
        except Exception as e:
            return f"خطا در دریافت محتوا: {str(e)}"