import os
import logging
import wikipedia
import re
import random
import sqlite3
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# تنظیمات
wikipedia.set_lang("fa")
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

TOKEN = "8275658185:AAHQHavsbELjUKrXcyIAmjm9FW5C247JzNc"

# پایگاه داده
def init_database():
    conn = sqlite3.connect('royan_bot.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            question_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# دکمه‌ها
def get_main_keyboard():
    keyboard = [
        [KeyboardButton("🎯 شروع دوستی"), KeyboardButton("📖 راهنما")],
        [KeyboardButton("🤖 درباره من"), KeyboardButton("😄 جوک")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# پاسخ‌های اصلی
FRIENDLY_RESPONSES = {
    "سلام": "سلام عزیزم! 😊 چطوری؟",
    "چطوری": "عالیم ممنون! تو چطوری قشنگ؟",
    "خوبی": "ممنون خوبم! تو خوبی؟",
    "چیکار میتونی بکنی": "هر سوالی داری ازم بپرس رفیق! من برات تو ویکی‌پدیا جستجو میکنم!",
    "جوک": "چرا کامپیوتر نمی‌تونه قایم باشک بازی کنه؟ چون همیشه مونیتورش رو روشن میذاره! 😄",
    "🎯 شروع دوستی": "هلا رفیق! 🤗 من رویانم، همیشه کنارتام!",
    "📖 راهنما": "فقط سوالت رو بپرس یا از دکمه‌ها استفاده کن!",
    "🤖 درباره من": "من رویانم، یه رفیق ایرانی که میتونه برات هر چیزی رو سرچ کنه!",
    "😄 جوک": "چرا کتاب ریاضی غمگین بود؟ چون کلی مشکل داشت! 📚"
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    await update.message.reply_html(
        f"🤗 <b>هلا {user.mention_html()} عزیزم!</b>\n\n"
        "من <b>رویان</b> هستم، رفیق جدیدت! 🫂\n\n"
        "می‌تونی هر سوالی داری ازم بپرسی یا از دکمه‌های پایین استفاده کنی!",
        reply_markup=get_main_keyboard()
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🫂 <b>راهنمای رفیقانه</b>\n\n"
        "• هر سوالی داری ازم بپرس\n"
        "• من برات تو ویکی‌پدیا جستجو می‌کنم\n"
        "• از دکمه‌ها استفاده کن\n\n"
        "همیشه کنارتام! 🤗",
        parse_mode='HTML',
        reply_markup=get_main_keyboard()
    )

def clean_text(text: str) -> str:
    text = re.sub(r'\[.*?\]', '', text)
    text = re.sub(r'\(.*?\)', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

async def search_wikipedia(query: str) -> str:
    try:
        page = wikipedia.page(query)
        summary = page.summary
        
        if len(summary) > 2000:
            summary = summary[:2000] + "..."
            
        return "🔍 <b>اینو برات پیدا کردم:</b>\n\n" + clean_text(summary)
    
    except wikipedia.exceptions.DisambiguationError as e:
        options = e.options[:3]
        response = "🤔 <b>رفیق یه کم دقیق‌تر بگو!</b> شاید منظورت اینا بود:\n\n"
        for option in options:
            response += f"• {option}\n"
        return response
    
    except wikipedia.exceptions.PageError:
        return "❌ <b>هیچی پیدا نکردم رفیق!</b> یه کم دیگه توضیح بده"
    
    except Exception as e:
        logger.error(f"Error: {e}")
        return "⚠️ <b>وای رفیق یه مشکلی پیش اومد!</b> دوباره تلاش کن"

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    
    if text in FRIENDLY_RESPONSES:
        await update.message.reply_text(
            FRIENDLY_RESPONSES[text],
            reply_markup=get_main_keyboard()
        )
        return
    
    # جستجو در ویکی‌پدیا
    await context.bot.send_chat_action(
        chat_id=update.effective_chat.id, 
        action="typing"
    )
    
    response = await search_wikipedia(text)
    await update.message.reply_html(
        response,
        reply_markup=get_main_keyboard()
    )

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Error: {context.error}")
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚠️ <b>وای رفیق یه مشکلی پیش اومد!</b>",
        parse_mode='HTML'
    )

def main():
    init_database()
    
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_error_handler(error_handler)
    
    print("🤖 ربات رویان در حال اجراست...")
    application.run_polling()

if __name__ == "__main__":
    main()