# file_processor.py
import io
import os
import tempfile
from typing import Optional, Tuple
import random

try:
    import PyPDF2
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

try:
    import docx
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False

try:
    from PIL import Image
    import pytesseract
    OCR_SUPPORT = True
except ImportError:
    OCR_SUPPORT = False

class FileProcessor:
    def __init__(self):
        self.supported_formats = self._get_supported_formats()
    
    def _get_supported_formats(self) -> dict:
        """فرمت‌های پشتیبانی شده"""
        formats = {
            'txt': {'reader': self._read_txt, 'mime_types': ['text/plain']},
        }
        
        if PDF_SUPPORT:
            formats['pdf'] = {'reader': self._read_pdf, 'mime_types': ['application/pdf']}
        
        if DOCX_SUPPORT:
            formats['docx'] = {'reader': self._read_docx, 'mime_types': [
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            ]}
            formats['doc'] = {'reader': self._read_docx, 'mime_types': ['application/msword']}
        
        if OCR_SUPPORT:
            formats.update({
                'jpg': {'reader': self._read_image, 'mime_types': ['image/jpeg']},
                'jpeg': {'reader': self._read_image, 'mime_types': ['image/jpeg']},
                'png': {'reader': self._read_image, 'mime_types': ['image/png']},
                'bmp': {'reader': self._read_image, 'mime_types': ['image/bmp']}
            })
        
        return formats
    
    def process_file(self, file_content: bytes, file_name: str) -> Tuple[bool, str, str]:
        """پردازش فایل و استخراج متن"""
        try:
            # تشخیص فرمت فایل
            file_ext = file_name.lower().split('.')[-1] if '.' in file_name else ''
            
            if file_ext not in self.supported_formats:
                error_msg = random.choice([
                    f"❌ وای! فرمت {file_ext} رو پشتیبانی نمی‌کنم!",
                    f"❌ اوف! فایل {file_ext} رو نمی‌تونم بخونم!",
                    f"❌ شرمنده! فایل‌های {file_ext} رو بلد نیستم!"
                ])
                return False, error_msg, ""
            
            # استخراج متن
            reader_func = self.supported_formats[file_ext]['reader']
            text_content = reader_func(file_content)
            
            if not text_content or len(text_content.strip()) < 10:
                error_msg = random.choice([
                    "❌ وای! نتونستم متن قابل خواندی از فایل استخراج کنم!",
                    "❌ اوف! فایل خالی به نظر می‌رسه یا متنش خیلی کمه!",
                    "❌ شرمنده! محتوای قابل استخراجی توی فایل پیدا نکردم!"
                ])
                return False, error_msg, ""
            
            success_msg = random.choice([
                f"✅ آفرین! فایل {file_name} رو با موفقیت خوندم! 📄",
                f"✅ عالی بود! متن فایل {file_name} رو استخراج کردم! 💫",
                f"✅ حله! فایل {file_name} رو پردازش کردم! 🎯"
            ])
            
            return True, success_msg, text_content
            
        except Exception as e:
            error_msg = random.choice([
                f"❌ وای! خطا در پردازش فایل: {str(e)}",
                f"❌ اوف! مشکلی در خواندن فایل پیش اومد: {str(e)}",
                f"❌ شرمنده! نتونستم فایل رو بخونم: {str(e)}"
            ])
            return False, error_msg, ""
    
    def _read_txt(self, file_content: bytes) -> str:
        """خواندن فایل متنی"""
        try:
            return file_content.decode('utf-8')
        except UnicodeDecodeError:
            # اگر UTF-8 جواب نداد، با encoding دیگه امتحان کن
            try:
                return file_content.decode('utf-16')
            except:
                return file_content.decode('latin-1')
    
    def _read_pdf(self, file_content: bytes) -> str:
        """خواندن فایل PDF"""
        if not PDF_SUPPORT:
            return "پشتیبانی از PDF فعال نیست"
        
        try:
            pdf_file = io.BytesIO(file_content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            
            return text.strip()
        except Exception as e:
            return f"خطا در خواندن PDF: {str(e)}"
    
    def _read_docx(self, file_content: bytes) -> str:
        """خواندن فایل Word"""
        if not DOCX_SUPPORT:
            return "پشتیبانی از Word فعال نیست"
        
        try:
            doc_file = io.BytesIO(file_content)
            doc = docx.Document(doc_file)
            
            text = ""
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    text += paragraph.text + "\n"
            
            return text.strip()
        except Exception as e:
            return f"خطا در خواندن Word: {str(e)}"
    
    def _read_image(self, file_content: bytes) -> str:
        """خواندن متن از تصویر با OCR"""
        if not OCR_SUPPORT:
            return "پشتیبانی از OCR فعال نیست"
        
        try:
            # ایجاد فایل موقت
            with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as temp_file:
                temp_file.write(file_content)
                temp_path = temp_file.name
            
            # استخراج متن با OCR
            image = Image.open(temp_path)
            
            # تنظیمات برای زبان فارسی
            custom_config = r'--oem 3 --psm 6 -l fas+eng'
            text = pytesseract.image_to_string(image, config=custom_config)
            
            # حذف فایل موقت
            os.unlink(temp_path)
            
            return text.strip()
        except Exception as e:
            return f"خطا در OCR: {str(e)}"
    
    def get_supported_formats_info(self) -> str:
        """دریافت اطلاعات فرمت‌های پشتیبانی شده"""
        formats_info = "📁 **فرمت‌های پشتیبانی شده:**\n\n"
        
        for fmt, info in self.supported_formats.items():
            formats_info += f"• **.{fmt}** - "
            
            if fmt == 'txt':
                formats_info += "فایل متنی ساده\n"
            elif fmt in ['pdf']:
                formats_info += "سند PDF\n"
            elif fmt in ['docx', 'doc']:
                formats_info += "سند Word\n"
            elif fmt in ['jpg', 'jpeg', 'png', 'bmp']:
                formats_info += "تصویر (متن استخراج می‌شود)\n"
        
        formats_info += "\n💫 می‌تونی هر کدوم از این فایل‌ها رو برام بفرستی!"
        
        return formats_info
    
    def estimate_reading_time(self, text: str) -> str:
        """تخمین زمان خواندن متن"""
        words_count = len(text.split())
        reading_time_minutes = words_count / 200  # فرض: ۲۰۰ کلمه در دقیقه
        
        if reading_time_minutes < 1:
            return "کمتر از ۱ دقیقه"
        elif reading_time_minutes < 2:
            return "حدود ۱ دقیقه"
        else:
            return f"حدود {int(reading_time_minutes)} دقیقه"

class SmartFileProcessor(FileProcessor):
    """پردازشگر فایل هوشمند با قابلیت‌های بیشتر"""
    
    def analyze_content(self, text: str) -> dict:
        """آنالیز محتوای متن"""
        words = text.split()
        sentences = text.split('.')
        
        # تشخیص زبان (ساده)
        persian_chars = sum(1 for char in text if '\u0600' <= char <= '\u06FF')
        english_chars = sum(1 for char in text if 'a' <= char.lower() <= 'z')
        
        if persian_chars > english_chars:
            language = "فارسی"
        else:
            language = "انگلیسی"
        
        return {
            'word_count': len(words),
            'sentence_count': len([s for s in sentences if s.strip()]),
            'language': language,
            'reading_time': self.estimate_reading_time(text),
            'has_questions': any('?' in s or '؟' in s for s in sentences),
            'content_preview': text[:200] + "..." if len(text) > 200 else text
        }
    
    def generate_file_summary(self, analysis: dict, file_name: str) -> str:
        """تولید خلاصه خودمونی از فایل"""
        summary = random.choice([
            f"📄 **خلاصه فایل {file_name}:**\n\n",
            f"💫 **آنالیز {file_name}:**\n\n",
            f"🎯 **بررسی فایل {file_name}:**\n\n"
        ])
        
        summary += f"• تعداد کلمات: {analysis['word_count']} تا\n"
        summary += f"• زبان: {analysis['language']}\n"
        summary += f"• زمان خواندن: {analysis['reading_time']}\n"
        
        if analysis['has_questions']:
            summary += "• ✅ شامل سوالات\n"
        else:
            summary += "• 📝 متن اطلاعاتی\n"
        
        summary += f"\n📖 **پیش‌نمایش:**\n{analysis['content_preview']}"
        
        return summary