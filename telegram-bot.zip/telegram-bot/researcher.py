# researcher.py
import requests
import re
import time
from bs4 import BeautifulSoup
from config import REQUEST_TIMEOUT
import random
import logging

# تنظیم لاگینگ
logger = logging.getLogger(__name__)

class SmartResearcher:
    def __init__(self):
        self.session = requests.Session()
        self.setup_session()
    
    def setup_session(self):
        """تنظیم session برای درخواست‌ها"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
        }
        self.session.headers.update(headers)

    def research_topic(self, query):
        """
        تحقیق هوشمند برای سوالات
        """
        try:
            print(f"🔍 شروع تحقیق برای: '{query}'")
            
            # 1. اول پاسخ‌های خودمونی برای سوالات شخصی
            if self.is_personal_question(query):
                casual_answer = self.try_casual_answer(query)
                if casual_answer:
                    print(f"✅ پاسخ خودمونی داده شد")
                    return casual_answer
            
            print("🔍 جستجو در منابع آنلاین...")
            
            # 2. ویکی‌پدیا فارسی
            wikipedia_result = self.get_from_wikipedia(query)
            if wikipedia_result:
                print("✅ نتیجه از ویکی‌پدیا پیدا شد")
                return wikipedia_result
            
            # 3. ویکی‌پدیا انگلیسی
            english_result = self.get_from_english_wikipedia(query)
            if english_result:
                print("✅ نتیجه از ویکی‌پدیا انگلیسی پیدا شد")
                return english_result
            
            # 4. جستجوی عمومی
            general_result = self.get_from_general_search(query)
            if general_result:
                print("✅ نتیجه از جستجوی عمومی پیدا شد")
                return general_result
            
            print("❌ هیچ نتیجه‌ای در تحقیق پیدا نشد")
            return self.get_fallback_response(query)
            
        except Exception as e:
            logger.error(f"خطا در تحقیق: {e}")
            return "❌ متأسفانه در حال حاضر مشکل فنی دارم. لطفاً کمی بعد تلاش کن!"

    def is_personal_question(self, query):
        """تشخیص سوالات شخصی درباره ربات"""
        personal_keywords = [
            'ساختت', 'اسمت', 'چند سالته', 'چکار میکنی', 'حالت چطوره', 
            'دوست داری', 'کیستی', 'کجایی', 'چرا', 'چطور', 'چطوری'
        ]
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in personal_keywords)

    def try_casual_answer(self, query):
        """پاسخ‌های خودمونی برای سوالات ساده"""
        query_lower = query.lower().strip()
        
        casual_qa = {
            'اسمت چیه': [
                "من رهام! 🤖 یه ربات باهوش که اینجام تا کمکت کنم",
                "من رها هستم! دوست دارم بهت کمک کنم 💫",
            ],
            'چند سالته': [
                "من یه رباتم عزیزم! سن و سال ندارم، همیشه تازه‌نفسم! 🎉",
            ],
            'ساختت': [
                "یه برنامه‌نویس باهوش منو ساخته تا به آدم‌ها کمک کنم! 💻",
            ],
            'ساختت کی': [
                "همیشه اینجام عزیزم! ولی اگه می‌خوای بدونی، یه برنامه‌نویس باهوش منو خلق کرده! 💫",
            ],
            'ساختت چرا': [
                "برای اینکه بتونم بهت کمک کنم و سوالاتتو جواب بدم! 🌈",
            ],
            'چکار میکنی': [
                "من اینجام تا هر سوالی داری جواب بدم! از من هر چی بخوای بپرس 🎯",
            ],
        }
        
        for question_pattern, answers in casual_qa.items():
            if question_pattern in query_lower:
                return random.choice(answers)
        
        return None

    def get_from_wikipedia(self, query):
        """دریافت اطلاعات از ویکی‌پدیا فارسی"""
        try:
            print(f"🔍 جستجو در ویکی‌پدیا فارسی: {query}")
            
            # جستجو در ویکی‌پدیا فارسی
            search_url = f"https://fa.wikipedia.org/w/api.php?action=query&list=search&srsearch={query}&format=json"
            
            response = self.session.get(search_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('query', {}).get('search'):
                    first_result = data['query']['search'][0]
                    title = first_result['title']
                    print(f"✅ صفحه پیدا شد: {title}")
                    
                    # دریافت محتوای صفحه
                    content_url = f"https://fa.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=true&explaintext=true&titles={title}&format=json"
                    content_response = self.session.get(content_url, timeout=10)
                    
                    if content_response.status_code == 200:
                        content_data = content_response.json()
                        pages = content_data['query']['pages']
                        for page_id, page_data in pages.items():
                            if 'extract' in page_data:
                                content = page_data['extract']
                                if self.is_meaningful_content(content):
                                    return self.format_wikipedia_response(content, title)
            return None
            
        except requests.exceptions.Timeout:
            print("⏰ timeout در ویکی‌پدیا فارسی")
            return None
        except Exception as e:
            print(f"❌ خطا در ویکی‌پدیا فارسی: {e}")
            return None

    def get_from_english_wikipedia(self, query):
        """دریافت اطلاعات از ویکی‌پدیا انگلیسی"""
        try:
            print(f"🔍 جستجو در ویکی‌پدیا انگلیسی: {query}")
            
            search_url = f"https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch={query}&format=json"
            response = self.session.get(search_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('query', {}).get('search'):
                    first_result = data['query']['search'][0]
                    title = first_result['title']
                    print(f"✅ صفحه انگلیسی پیدا شد: {title}")
                    
                    content_url = f"https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=true&explaintext=true&titles={title}&format=json"
                    content_response = self.session.get(content_url, timeout=10)
                    
                    if content_response.status_code == 200:
                        content_data = content_response.json()
                        pages = content_data['query']['pages']
                        for page_id, page_data in pages.items():
                            if 'extract' in page_data:
                                content = page_data['extract']
                                if self.is_meaningful_content(content):
                                    summary = self.summarize_english_content(content)
                                    if summary:
                                        return f"📚 **بر اساس ویکی‌پدیا انگلیسی:**\n\n{summary}\n\n🔍 *منبع: Wikipedia*"
            return None
            
        except requests.exceptions.Timeout:
            print("⏰ timeout در ویکی‌پدیا انگلیسی")
            return None
        except Exception as e:
            print(f"❌ خطا در ویکی‌پدیا انگلیسی: {e}")
            return None

    def get_from_general_search(self, query):
        """جستجوی عمومی در اینترنت"""
        try:
            print(f"🔍 جستجوی عمومی: {query}")
            
            # جستجوی ساده با درخواست مستقیم
            search_url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1"
            response = self.session.get(search_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # بررسی Abstract
                if data.get('Abstract'):
                    abstract = data['Abstract']
                    if self.is_meaningful_content(abstract):
                        return f"📚 **بر اساس جستجوی اینترنتی:**\n\n{abstract}\n\n🔍 *منبع: DuckDuckGo*"
                
                # بررسی RelatedTopics
                if data.get('RelatedTopics'):
                    for topic in data['RelatedTopics'][:2]:
                        if topic.get('Text'):
                            text = topic['Text']
                            if self.is_meaningful_content(text):
                                return f"📚 **بر اساس جستجوی اینترنتی:**\n\n{text[:500]}...\n\n🔍 *منبع: DuckDuckGo*"
            
            return None
            
        except Exception as e:
            print(f"❌ خطا در جستجوی عمومی: {e}")
            return None

    def summarize_english_content(self, content):
        """خلاصه‌سازی محتوای انگلیسی"""
        try:
            sentences = re.split(r'[.!?]', content)
            sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
            
            if sentences:
                summary = '. '.join(sentences[:2])
                return summary + " (ترجمه شده)"
            
            return content[:300] + " (ترجمه شده)"
        except:
            return None

    def is_meaningful_content(self, text):
        """بررسی معنادار بودن محتوا"""
        if not text or len(text.strip()) < 30:
            return False
        
        text_lower = text.lower()
        
        # فیلتر محتوای بی‌ربط
        irrelevant_terms = [
            'disambiguation', 'redirect', 'search results', 'login',
            'sign up', 'subscribe', 'advertisement'
        ]
        
        for term in irrelevant_terms:
            if term in text_lower:
                return False
        
        return text_lower.count(' ') >= 3

    def format_wikipedia_response(self, content, title):
        """فرمت‌دهی پاسخ ویکی‌پدیا"""
        sentences = content.split('.')
        meaningful_sentences = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 20 and self.is_meaningful_content(sentence):
                meaningful_sentences.append(sentence)
            if len(meaningful_sentences) >= 3:
                break
        
        if meaningful_sentences:
            summary = '. '.join(meaningful_sentences)
            return f"📚 **بر اساس ویکی‌پدیا ({title}):**\n\n{summary}\n\n🔍 *منبع: Wikipedia*"
        
        return None

    def get_fallback_response(self, query):
        """پاسخ پیش‌فرض وقتی هیچ نتیجه‌ای پیدا نشد"""
        fallback_responses = [
            f"🤔 نتونستم اطلاعاتی درباره '{query}' پیدا کنم. می‌تونی سوالت رو دقیق‌تر بپرسی یا از /learn استفاده کنی تا بهم یاد بدی!",
            f"💫 درباره '{query}' اطلاعاتی ندارم. دوست داری خودت بهم یادش بدی؟",
            f"🎯 فعلاً پاسخی برای '{query}' ندارم. می‌شوی یه توضیح کوچیک در موردش بدی؟"
        ]
        return random.choice(fallback_responses)