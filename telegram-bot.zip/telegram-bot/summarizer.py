# summarizer.py
import re
import random
from typing import List, Dict, Any
from database import KnowledgeDB
from nlp_processor import PersianNLP

class SmartSummarizer:
    def __init__(self):
        self.db = KnowledgeDB()
        self.nlp = PersianNLP()
        self.summary_templates = self._load_summary_templates()
    
    def _load_summary_templates(self) -> Dict[str, List[str]]:
        """لود تمپلیت‌های خلاصه با حال و هوای خودمونی"""
        return {
            'intro': [
                "📊 **خلاصه‌ای از اطلاعات موجود درباره '{}':**\n\n",
                "💫 **اینم جمع‌بندی مطالب در مورد '{}':**\n\n",
                "🎯 **خلاصه‌ی دانش من درباره '{}':**\n\n",
                "📚 **بررسی کلی '{}':**\n\n"
            ],
            'category_header': [
                "\n📁 **در دسته‌بندی {}:**\n",
                "\n📂 **موضوعات مرتبط با {}:**\n",
                "\n🗂️ **در بخش {}:**\n"
            ],
            'item_bullet': [
                "• **{}:** {}",
                "🔸 **{}:** {}",
                "🎯 **{}:** {}",
                "💡 **{}:** {}"
            ],
            'outro': [
                "\n\n💝 *امیدوارم این خلاصه برات مفید بوده باشه!*",
                "\n\n🌈 *اگر سوال دیگه‌ای داری، فقط بپرس!*",
                "\n\n🚀 *همینطور ادامه بده، داره عالی پیش می‌ری!*",
                "\n\n🎯 *حتماً بازم سوال بپرس، من اینجام برات!*"
            ]
        }
    
    def summarize_knowledge(self, query: str, search_results: List = None) -> str:
        """
        خلاصه‌سازی هوشمند اطلاعات از چندین منبع
        """
        try:
            if not search_results:
                search_results = self.db.search_knowledge(query, limit=10)
            
            if not search_results:
                return self._get_no_results_response(query)
            
            # جمع‌آوری و دسته‌بندی مطالب مرتبط
            categorized_content = self._categorize_content(search_results)
            
            # ایجاد خلاصه ساختاریافته
            summary = self._create_structured_summary(query, categorized_content)
            
            return summary
            
        except Exception as e:
            return random.choice([
                f"❌ وای! خطا در ایجاد خلاصه: {str(e)}",
                f"❌ اوف! مشکلی در خلاصه‌سازی پیش اومد: {str(e)}",
                f"❌ شرمنده! نتونستم خلاصه ایجاد کنم: {str(e)}"
            ])
    
    def _get_no_results_response(self, query: str) -> str:
        """پاسخ وقتی هیچ نتیجه‌ای پیدا نشد"""
        no_result_responses = [
            f"❌ وای! هیچ اطلاعاتی در مورد '{query}' پیدا نکردم!\n\n💡 می‌تونی:\n• سوالت رو دقیق‌تر بپرسی\n• با /learn بهم یاد بدی\n• از لینک سایت استفاده کنی",
            f"❌ اوف! چیزی درباره '{query}' بلد نیستم!\n\n🎯 پیشنهاد:\n• سوالت رو واضح‌تر بپرس\n• از /learn کمک بگیر\n• یه توضیح کوچیک بهم بده",
            f"❌ شرمنده! اطلاعاتی از '{query}' ندارم!\n\n💫 راه‌حل:\n• دقیق‌تر سوال کن\n• با /learn آموزش بده\n• بیشتر توضیح بده"
        ]
        return random.choice(no_result_responses)
    
    def _categorize_content(self, search_results: List) -> Dict[str, List]:
        """دسته‌بندی محتوا بر اساس موضوع و ارتباط"""
        categories = {}
        
        for result in search_results:
            category = result[1]  # دسته‌بندی
            topic = result[2]     # موضوع
            content = result[3]   # محتوا
            usage_count = result[7]  # تعداد استفاده
            
            if category not in categories:
                categories[category] = []
            
            categories[category].append({
                'topic': topic,
                'content': content,
                'usage_count': usage_count,
                'relevance': self._calculate_relevance(topic, content, usage_count)
            })
        
        return categories
    
    def _calculate_relevance(self, topic: str, content: str, usage_count: int) -> float:
        """محاسبه میزان ارتباط محتوا"""
        relevance = 0.0
        
        # امتیاز بر اساس طول محتوا
        relevance += min(len(content) / 1000, 2.0)  # حداکثر ۲ امتیاز
        
        # امتیاز بر اساس تعداد استفاده
        relevance += min(usage_count / 50, 3.0)  # حداکثر ۳ امتیاز
        
        # امتیاز بر اساس خوانایی (تعداد جملات)
        sentences = [s.strip() for s in content.split('.') if s.strip()]
        relevance += min(len(sentences) / 10, 1.0)  # حداکثر ۱ امتیاز
        
        return relevance
    
    def _create_structured_summary(self, query: str, categorized_content: Dict) -> str:
        """ایجاد خلاصه ساختاریافته"""
        if not categorized_content:
            return "❌ اطلاعات کافی برای ایجاد خلاصه پیدا نشد."
        
        # انتخاب تمپلیت intro
        intro_template = random.choice(self.summary_templates['intro'])
        summary = intro_template.format(query)
        
        total_sources = sum(len(content_list) for content_list in categorized_content.values())
        total_categories = len(categorized_content)
        
        # اضافه کردن آمار کلی
        stats_intros = [
            f"📈 بر اساس {total_sources} منبع در {total_categories} دسته مختلف:\n\n",
            f"🔍 جمع‌آوری شده از {total_sources} مطلب در {total_categories} بخش:\n\n",
            f"💫 استخراج شده از {total_sources} اطلاعات در {total_categories} گروه:\n\n"
        ]
        summary += random.choice(stats_intros)
        
        # اضافه کردن محتوای هر دسته‌بندی
        for category, contents in categorized_content.items():
            # هدر دسته‌بندی
            category_header = random.choice(self.summary_templates['category_header'])
            summary += category_header.format(category)
            
            # مرتب‌سازی بر اساس ارتباط
            sorted_contents = sorted(contents, key=lambda x: x['relevance'], reverse=True)
            
            # اضافه کردن آیتم‌های هر دسته (حداکثر ۳ مورد)
            for i, content_item in enumerate(sorted_contents[:3]):
                topic = content_item['topic']
                content = content_item['content']
                
                # خلاصه‌سازی محتوای هر آیتم
                item_summary = self._summarize_text(content, 120)
                
                # انتخاب تمپلیت بولت
                bullet_template = random.choice(self.summary_templates['item_bullet'])
                summary += f"\n{bullet_template.format(topic, item_summary)}"
        
        # اضافه کردن نکات کلیدی
        key_points = self._extract_key_points(categorized_content)
        if key_points:
            key_point_intros = [
                "\n\n💡 **نکات کلیدی:**\n",
                "\n\n🎯 **مهم‌ترین نکات:**\n",
                "\n\n🌟 **جمع‌بندی اصلی:**\n"
            ]
            summary += random.choice(key_point_intros)
            
            for point in key_points[:3]:  # حداکثر ۳ نکته
                summary += f"• {point}\n"
        
        # اضافه کردن outro
        outro_template = random.choice(self.summary_templates['outro'])
        summary += outro_template
        
        return summary
    
    def _summarize_text(self, text: str, max_length: int = 150) -> str:
        """خلاصه‌سازی متن با حفظ معنا"""
        if len(text) <= max_length:
            return text
        
        # پیدا کردن نقطه قطع مناسب بر اساس جملات
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        summary = ''
        
        for sentence in sentences:
            if sentence and len(summary + sentence) < max_length:
                summary += sentence + '. '
            else:
                break
        
        if not summary:
            # اگر نتوانستیم با نقطه قطع کنیم، ساده قطع می‌کنیم
            summary = text[:max_length-3] + '...'
        
        return summary.strip()
    
    def _extract_key_points(self, categorized_content: Dict) -> List[str]:
        """استخراج نکات کلیدی از تمام محتوا"""
        all_contents = []
        for contents in categorized_content.values():
            for item in contents:
                all_contents.append(item['content'])
        
        # پیدا کردن جملات کلیدی (ساده)
        key_sentences = []
        for content in all_contents:
            sentences = [s.strip() for s in content.split('.') if s.strip() and len(s) > 20]
            if sentences:
                # اولین جمله معمولاً تعریفی است
                key_sentences.append(sentences[0])
            
            if len(key_sentences) >= 5:  # حداکثر ۵ نکته
                break
        
        return key_sentences[:5]
    
    def create_comprehensive_summary(self, query: str) -> str:
        """خلاصه جامع با ترکیب دیتابیس و تحقیق"""
        # جستجو در دیتابیس
        db_results = self.db.search_knowledge(query, limit=15)
        
        # اگر نتایج کافی نبود، جستجوی گسترده‌تر
        if len(db_results) < 3:
            db_results = self.db.search_knowledge(query.split()[0] if query.split() else query, limit=20)
        
        return self.summarize_knowledge(query, db_results)

class CasualSummarizer(SmartSummarizer):
    """سامریزر با حال و هوای خودمونی"""
    
    def create_friendly_summary(self, query: str, user_name: str = "عزیزم") -> str:
        """خلاصه با لحن دوستانه و خودمونی"""
        summary = self.create_comprehensive_summary(query)
        
        # اگر خطا بود، همان را برگردان
        if summary.startswith("❌"):
            return summary
        
        # اضافه کردن لحن خودمونی
        friendly_addons = [
            f"\n\n💖 راستی {user_name}، اگر نکته خاصی مد نظرت هست بگو!",
            f"\n\n🌸 {user_name} جان، اگر جاییش رو نفهمیدی دوباره بپرس!",
            f"\n\n💫 {user_name} عزیزم، هر سوال دیگه‌ای داشتی در خدمتم!",
            f"\n\n🎯 {user_name} قشنگم، اگر نیاز به توضیح بیشتر داری بگو!"
        ]
        
        return summary + random.choice(friendly_addons)
    
    def quick_summary(self, query: str) -> str:
        """خلاصه سریع و مختصر"""
        results = self.db.search_knowledge(query, limit=5)
        
        if not results:
            return random.choice([
                "❌ وای! چیزی درباره این موضوع پیدا نکردم!",
                "❌ اوف! این یکی رو بلد نیستم!",
                "❌ شرمنده! اطلاعاتی از این موضوع ندارم!"
            ])
        
        # خلاصه خیلی کوتاه از اولین نتیجه
        first_result = results[0]
        topic = first_result[2]
        content = first_result[3]
        
        quick_summaries = [
            f"🎯 **خلاصه سریع درباره {topic}:**\n\n{self._summarize_text(content, 200)}",
            f"💫 **خلاصه فوری {topic}:**\n\n{self._summarize_text(content, 200)}",
            f"🔍 **خلاصه کوتاه {topic}:**\n\n{self._summarize_text(content, 200)}"
        ]
        
        return random.choice(quick_summaries)

class AdvancedSummarizer(SmartSummarizer):
    """سامریزر پیشرفته با قابلیت‌های بیشتر"""
    
    def summarize_by_category(self, query: str, category: str = None) -> str:
        """خلاصه‌سازی در دسته‌بندی خاص"""
        if category:
            results = self.db.search_knowledge(query, category=category, limit=10)
        else:
            results = self.db.search_knowledge(query, limit=10)
        
        if not results:
            return f"❌ هیچ اطلاعاتی در دسته‌بندی '{category}' درباره '{query}' پیدا نکردم."
        
        return self.summarize_knowledge(query, results)
    
    def compare_topics(self, topic1: str, topic2: str) -> str:
        """خلاصه مقایسه‌ای بین دو موضوع"""
        results1 = self.db.search_knowledge(topic1, limit=5)
        results2 = self.db.search_knowledge(topic2, limit=5)
        
        if not results1 and not results2:
            return "❌ اطلاعات کافی برای مقایسه این دو موضوع ندارم."
        
        comparison_intros = [
            f"📊 **مقایسه بین '{topic1}' و '{topic2}':**\n\n",
            f"⚖️ **بررسی تفاوت‌های '{topic1}' و '{topic2}':**\n\n",
            f"🔍 **مقایسه '{topic1}' با '{topic2}':**\n\n"
        ]
        
        comparison = random.choice(comparison_intros)
        
        if results1:
            first_topic1 = results1[0]
            comparison += f"🎯 **{topic1}:**\n{self._summarize_text(first_topic1[3], 150)}\n\n"
        
        if results2:
            first_topic2 = results2[0]
            comparison += f"🎯 **{topic2}:**\n{self._summarize_text(first_topic2[3], 150)}\n\n"
        
        comparison += random.choice([
            "💡 *برای اطلاعات بیشتر می‌تونی در مورد هر کدوم جداگانه سوال بپرسی!*",
            "🌟 *اگر نکته خاصی در مقایسه این دو مد نظرته، بپرس!*",
            "🎯 *می‌تونی دقیق‌تر بگی کدوم جنبه مقایسه برات مهم‌تره؟*"
        ])
        
        return comparison