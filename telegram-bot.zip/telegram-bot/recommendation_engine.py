# recommendation_engine.py
from database import KnowledgeDB
from collections import defaultdict, Counter
import random
from typing import List, Dict, Any
from datetime import datetime, timedelta

class RecommendationEngine:
    def __init__(self):
        self.db = KnowledgeDB()
        self.user_interactions = defaultdict(list)
        self.user_preferences = defaultdict(dict)
    
    def record_interaction(self, user_id: int, topic: str, interaction_type: str = 'view', rating: int = None):
        """ثبت تعامل کاربر"""
        interaction = {
            'topic': topic,
            'type': interaction_type,
            'rating': rating,
            'timestamp': datetime.now()
        }
        
        self.user_interactions[user_id].append(interaction)
        
        # محدود کردن تاریخچه به ۱۰۰ مورد اخیر
        if len(self.user_interactions[user_id]) > 100:
            self.user_interactions[user_id] = self.user_interactions[user_id][-100:]
        
        # به‌روزرسانی ترجیحات کاربر
        self._update_user_preferences(user_id, topic, interaction_type, rating)
    
    def _update_user_preferences(self, user_id: int, topic: str, interaction_type: str, rating: int):
        """به‌روزرسانی ترجیحات کاربر"""
        if user_id not in self.user_preferences:
            self.user_preferences[user_id] = {
                'preferred_categories': Counter(),
                'preferred_topics': Counter(),
                'total_interactions': 0
            }
        
        user_prefs = self.user_preferences[user_id]
        
        # افزایش وزن برای تعاملات اخیر
        weight = 1
        if interaction_type == 'search':
            weight = 2
        elif interaction_type == 'save':
            weight = 3
        elif rating and rating > 3:
            weight = rating
        
        # پیدا کردن دسته‌بندی موضوع
        results = self.db.search_knowledge(topic, limit=1)
        if results:
            category = results[0][1]  # دسته‌بندی
            user_prefs['preferred_categories'][category] += weight
        
        user_prefs['preferred_topics'][topic] += weight
        user_prefs['total_interactions'] += 1
    
    def get_personalized_recommendations(self, user_id: int, limit: int = 5) -> List[Dict[str, Any]]:
        """پیشنهادات شخصی‌سازی شده برای کاربر"""
        user_history = self.user_interactions.get(user_id, [])
        
        if not user_history:
            return self.get_trending_recommendations(limit)
        
        # تحلیل تاریخچه کاربر
        user_prefs = self.user_preferences.get(user_id, {})
        preferred_categories = user_prefs.get('preferred_categories', Counter())
        preferred_topics = user_prefs.get('preferred_topics', Counter())
        
        recommendations = []
        
        # پیشنهاد بر اساس دسته‌بندی‌های محبوب
        for category, score in preferred_categories.most_common(3):
            category_recs = self._get_recommendations_by_category(category, limit=2)
            recommendations.extend(category_recs)
        
        # پیشنهاد بر اساس موضوعات مرتبط
        for topic, score in preferred_topics.most_common(3):
            related_recs = self._get_related_recommendations(topic, limit=2)
            recommendations.extend(related_recs)
        
        # حذف تکراری‌ها و مرتب‌سازی
        unique_recommendations = self._remove_duplicates(recommendations)
        sorted_recommendations = sorted(
            unique_recommendations, 
            key=lambda x: x.get('relevance_score', 0), 
            reverse=True
        )
        
        return sorted_recommendations[:limit]
    
    def _get_recommendations_by_category(self, category: str, limit: int = 3) -> List[Dict[str, Any]]:
        """پیشنهادات بر اساس دسته‌بندی"""
        results = self.db.search_knowledge("", category=category, limit=limit * 2)
        
        recommendations = []
        for result in results:
            rec = {
                'topic': result[2],
                'category': result[1],
                'content_preview': result[3][:100] + "..." if len(result[3]) > 100 else result[3],
                'usage_count': result[7],
                'relevance_score': result[7] / 100  # نمره ساده
            }
            recommendations.append(rec)
        
        return recommendations[:limit]
    
    def _get_related_recommendations(self, topic: str, limit: int = 3) -> List[Dict[str, Any]]:
        """پیشنهادات مرتبط با موضوع"""
        results = self.db.search_knowledge(topic, limit=limit * 2)
        
        recommendations = []
        for result in results:
            if result[2].lower() != topic.lower():  # جلوگیری از پیشنهاد خود موضوع
                rec = {
                    'topic': result[2],
                    'category': result[1],
                    'content_preview': result[3][:100] + "..." if len(result[3]) > 100 else result[3],
                    'usage_count': result[7],
                    'relevance_score': result[7] / 100
                }
                recommendations.append(rec)
        
        return recommendations[:limit]
    
    def _remove_duplicates(self, recommendations: List[Dict]) -> List[Dict]:
        """حذف پیشنهادات تکراری"""
        seen_topics = set()
        unique_recommendations = []
        
        for rec in recommendations:
            if rec['topic'] not in seen_topics:
                seen_topics.add(rec['topic'])
                unique_recommendations.append(rec)
        
        return unique_recommendations
    
    def get_trending_recommendations(self, limit: int = 5) -> List[Dict[str, Any]]:
        """پیشنهادات پرطرفدار"""
        popular_topics = self.db.get_popular_topics(limit * 2)
        
        recommendations = []
        for topic, category, usage_count in popular_topics:
            rec = {
                'topic': topic,
                'category': category,
                'content_preview': f"موضوع پرطرفدار با {usage_count} بار استفاده",
                'usage_count': usage_count,
                'relevance_score': usage_count / 100
            }
            recommendations.append(rec)
        
        return recommendations[:limit]
    
    def get_similar_users_recommendations(self, user_id: int, limit: int = 5) -> List[Dict[str, Any]]:
        """پیشنهادات بر اساس کاربران مشابه (پیاده‌سازی ساده)"""
        # این تابع می‌تواند با تحلیل کاربران مشابه پیاده‌سازی کامل‌تر شود
        return self.get_trending_recommendations(limit)
    
    def get_user_profile(self, user_id: int) -> Dict[str, Any]:
        """دریافت پروفایل کاربر"""
        user_history = self.user_interactions.get(user_id, [])
        user_prefs = self.user_preferences.get(user_id, {})
        
        if not user_history:
            return {
                'interaction_count': 0,
                'preferred_categories': [],
                'preferred_topics': [],
                'activity_level': 'تازه‌کار'
            }
        
        # تحلیل سطح فعالیت
        interaction_count = len(user_history)
        if interaction_count > 50:
            activity_level = "فعال"
        elif interaction_count > 20:
            activity_level = "متوسط"
        else:
            activity_level = "تازه‌کار"
        
        preferred_categories = [
            {'category': cat, 'score': score}
            for cat, score in user_prefs.get('preferred_categories', Counter()).most_common(5)
        ]
        
        preferred_topics = [
            {'topic': topic, 'score': score}
            for topic, score in user_prefs.get('preferred_topics', Counter()).most_common(5)
        ]
        
        return {
            'interaction_count': interaction_count,
            'preferred_categories': preferred_categories,
            'preferred_topics': preferred_topics,
            'activity_level': activity_level,
            'last_active': user_history[-1]['timestamp'] if user_history else None
        }

class CasualRecommendationEngine(RecommendationEngine):
    """موتور پیشنهاد با حال و هوای خودمونی"""
    
    def get_friendly_recommendations(self, user_id: int, limit: int = 5) -> List[Dict[str, Any]]:
        """پیشنهادات با لحن خودمونی"""
        recommendations = self.get_personalized_recommendations(user_id, limit)
        
        # اضافه کردن توضیحات خودمونی
        friendly_descriptions = [
            "اینم یه موضوع باحال که فکر می‌کنم دوست داشته باشی! 💫",
            "بهت پیشنهاد می‌کنم این رو حتما ببینی! 🎯",
            "فکر می‌کنم از این خوشت بیاد! 🌈",
            "اینم یه پیشنهاد ویژه برات! 💝",
            "حتما این موضوع رو بررسی کن! 🚀"
        ]
        
        for i, rec in enumerate(recommendations):
            rec['friendly_description'] = random.choice(friendly_descriptions)
        
        return recommendations