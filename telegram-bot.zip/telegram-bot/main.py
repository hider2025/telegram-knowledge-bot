# main.py
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram import BotCommand
from config import BOT_TOKEN
from database import KnowledgeDB
from researcher import SmartResearcher
from scraper import WebsiteScraper
from summarizer import SmartSummarizer
from nlp_processor import PersianNLP
from cache_manager import CacheManager
from recommendation_engine import RecommendationEngine
from file_processor import FileProcessor
from security_manager import SecurityManager
import logging
import random

# تنظیم لاگینگ
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# شیء دیتابیس و ماژول‌ها
db = KnowledgeDB()
researcher = SmartResearcher()
scraper = WebsiteScraper()
summarizer = SmartSummarizer()
nlp_processor = PersianNLP()
cache_manager = CacheManager()
recommendation_engine = RecommendationEngine()
file_processor = FileProcessor()
security_manager = SecurityManager()

# دیکشنری برای مدیریت حالت کاربران
user_sessions = {}

# منوی اصلی
main_keyboard = ReplyKeyboardMarkup([
    ["🤔 سوال بپرس", "📚 خلاصه هوشمند"],
    ["🌐 از سایت یاد بگیر", "📁 موضوعات موجود"],
    ["💡 پیشنهادات هوشمند", "📊 آمار و اطلاعات"],
    ["🎯 آموزش ربات", "❓ راهنما"]
], resize_keyboard=True, input_field_placeholder="دوست داری چیکار کنی؟")

# پاسخ‌های عامیانه
casual_responses = {
    'سلام': [
        "سلام عزیزم! 😊 چطوری؟ چیکار می‌تونم برات بکنم؟",
        "سلام قشنگم! 💫 چه خبر خوبی برام داری؟",
        "سلام داداش! 👋 امروز چه سوالی توی دلت هست؟",
    ],
    'خوبی': [
        "عالییم ممنون! تو چطوری گلم؟ 💚",
        "به لطف تو خیلی خوبم! تو چطوری قشنگم؟ 🌈",
        "دمم گرم! تو چطوری پشیم؟ 💖",
    ],
    'چطوری': [
        "خیلی خوبم عزیزم! چه خبر؟ 📢",
        "دمم گرم! تو چطوری گلم؟ 💖",
        "حالم توپه! راستی تو چطور می‌گذره؟ 🌈",
    ],
    'ممنون': [
        "خواهش می‌کنم عزیزم! 💝",
        "قربونت برم گلم! 😍",
        "کاری نکردم جونم! 🤗",
    ],
    'مرسی': [
        "قربون تو برم گلم! 😘",
        "خواهش می‌کنم قشنگم! 💝",
        "چیزیش نیس جونم! 🤗",
    ],
    'خداحافظ': [
        "خداحافظ گلم! موفق باشی 🌟",
        "بای بای قشنگم! 👋",
        "خداحافظ عزیزم! همیشه شاد باشی 💫",
    ],
    'بای': [
        "خداحافظ گلم! 💚",
        "بای بای قشنگم! 👋",
        "موفق باشی عزیزم! 💫",
    ],
    'شب بخیر': [
        "شب بخیر گلم! 🌙 خواب‌های قشنگ ببینی",
        "شب بخیر قشنگم! 💤 خوابت شیرین",
        "شب بخیر عزیزم! ✨ فردا رو ببینمت",
    ],
    'صبح بخیر': [
        "صبح بخیر گلم! 🌅 روزت پر از انرژی",
        "صبح بخیر قشنگم! ☀️ روز خوبی داشته باشی",
        "صبح بخیر عزیزم! 🌈 صبحت بخیر",
    ]
}

# تعریف commands برای ربات
async def setup_commands(application):
    commands = [
        BotCommand("start", "شروع کار با ربات"),
        BotCommand("learn", "یاد دادن مطلب جدید به ربات"),
        BotCommand("ask", "پرسیدن سوال از ربات"),
        BotCommand("summary", "دریافت خلاصه هوشمند"),
        BotCommand("website", "یادگیری ربات از سایت"),
        BotCommand("upload", "آموزش ربات با فایل"),
        BotCommand("categories", "موضوعات موجود"),
        BotCommand("recommend", "پیشنهادات هوشمند"),
        BotCommand("stats", "آمار ربات"),
        BotCommand("help", "راهنمای کامل")
    ]
    await application.bot.set_my_commands(commands)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = update.effective_user
    
    # ثبت کاربر در دیتابیس
    db.update_user_activity(
        user_id, 
        user.username, 
        user.first_name, 
        user.last_name
    )
    
    user_sessions[user_id] = {'mode': 'ready'}
    
    welcome_text = f"""
🤖 **سلام {user.first_name or 'عزیزم'}! به ربات دانش هوشمند خوش اومدی!**

🎯 **من رهام و می‌تونم:**
• به سوالاتت جواب بدم 🔍
• از اینترنت برات تحقیق کنم 🌐  
• اطلاعات رو برات خلاصه کنم 📊
• از سایت‌ها برات یاد بگیرم 📚

💫 **راستی می‌تونی:**
- مستقیماً سوالت رو بپرسی
- فایل برام بفرستی
- لینک سایت بدی

**بیا شروع کنیم!** 🚀
    """
    
    await update.message.reply_text(welcome_text, reply_markup=main_keyboard, parse_mode='Markdown')

async def learn_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_category'}
    
    await update.message.reply_text(
        "📝 **حله! می‌خوای چیزی یادم بدی?**\n\nلطفاً اول دسته‌بندی رو بگو:\n(مثلاً: برنامه‌نویسی، سلامت، علمی، عمومی)",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def ask_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_query'}
    
    await update.message.reply_text(
        "🤔 **باشه! الان سوالت رو بپرس:**\n\nهر سوالی داری بپرس، من جوابش رو پیدا می‌کنم!",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def website_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_url'}
    
    await update.message.reply_text(
        "🌐 **آفرین! می‌خوای از یه سایت یادم بدی!**\n\nلطفاً لینک سایت رو برام بفرست:",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def upload_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_file'}
    
    await update.message.reply_text(
        "📄 **حله! می‌خوای با فایل یادم بدی!**\n\nلطفاً فایل رو آپلود کن (PDF, Word, عکس):",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def summary_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'waiting_summary_query'}
    
    await update.message.reply_text(
        "📊 **حله! می‌خوای خلاصه‌ای از چیزی رو ببینی!**\n\nچه موضوعی رو می‌خوای خلاصه‌اش رو ببینم?",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def recommend_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions[user_id] = {'mode': 'ready'}
    
    await update.message.reply_text("💡 در حال پیدا کردن پیشنهادات جالب برات...")
    
    recommendations = recommendation_engine.get_personalized_recommendations(user_id)
    
    if recommendations:
        response = "🎯 **اینم از پیشنهادات ویژه برات:**\n\n"
        for i, rec in enumerate(recommendations, 1):
            response += f"{i}. **{rec['topic']}** - {rec['category']}\n"
        
        response += "\n💫 می‌تونی در مورد هر کدوم سوال بپرسی!"
    else:
        response = "🤔 هنوز نمی‌دونم چه چیزایی دوست داری! چند تا سوال بپرس تا بهتر بتونم پیشنهاد بدم!"
    
    await update.message.reply_text(response, reply_markup=main_keyboard, parse_mode='Markdown')

async def categories_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    categories = db.get_categories()
    if categories:
        categories_text = "\n".join([f"• {cat}" for cat in categories[:15]])
        response = f"📂 **اینم از موضوعات باحالی که داریم:**\n\n{categories_text}"
        
        if len(categories) > 15:
            response += f"\n\n... و {len(categories) - 15} موضوع دیگه!"
            
        await update.message.reply_text(response, reply_markup=main_keyboard)
    else:
        await update.message.reply_text(
            "📭 وای! هنوز موضوعی اضافه نکردیم!\n\nمی‌تونی با /learn موضوعات جدید اضافه کنی!",
            reply_markup=main_keyboard
        )

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    stats = db.get_stats()
    popular_topics = db.get_popular_topics(5)
    
    stats_text = f"""
📈 **اینم از آمار باحالمون:**

• کل اطلاعات: {stats['total_records']} تا
• دسته‌بندی‌ها: {stats['total_categories']} تا  
• موضوعات: {stats['total_topics']} تا
• استفاده‌ها: {stats['total_usage']} بار
• کاربران: {stats['total_users']} نفر

🔥 **موضوعات داغمون:**
"""
    
    for i, (topic, category, usage) in enumerate(popular_topics, 1):
        stats_text += f"{i}. {topic} - {usage} بار\n"
    
    stats_text += "\n💝 ممنون که بهم جان دادی!"
    
    await update.message.reply_text(stats_text, reply_markup=main_keyboard)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = """
📖 **راهنمای کامل ربات:**

🎯 **دستورهای اصلی:**
/start - شروع ربات
/ask - پرسش از ربات  
/summary - خلاصه هوشمند
/learn - آموزش ربات
/website - یادگیری از لینک
/upload - آموزش با فایل
/recommend - پیشنهادات هوشمند
/categories - موضوعات موجود
/stats - آمار ربات
/help - این راهنما

🔍 **نحوه کار:**
۱. مستقیماً سوال بپرس (مثلاً: «پایتون چیست؟»)
۲. ربات اول در دانش خودش جستجو می‌کنه
۳. اگر جواب رو نداشت، در اینترنت تحقیق می‌کنه  
۴. اطلاعات جدید رو یاد می‌گیره و ذخیره می‌کنه

🌐 **یادگیری از سایت:**
• لینک سایت رو بفرست
• ربات محتوا رو استخراج می‌کنه
• دسته‌بندی انتخاب کن
• اطلاعات ذخیره میشه

💡 **نکات:**
• سوالات رو دقیق و واضح بپرس
• از لینک‌های معتبر استفاده کن
• ربات دائماً در حال یادگیریه!
    """
    
    await update.message.reply_text(help_text, reply_markup=main_keyboard)

def is_casual_message(text):
    """تشخیص پیام‌های عامیانه"""
    text_lower = text.lower().strip()
    for key in casual_responses.keys():
        if key in text_lower:
            return key
    return None

def is_question(text):
    """تشخیص خودکار سوال"""
    if not text or len(text.strip()) < 2:
        return False
    
    text_lower = text.lower().strip()
    
    # کلمات و نشانه‌های سوالی
    question_indicators = [
        '؟', '?', 'چه', 'چگونه', 'چرا', 'کی', 'کجا', 'چطور', 
        'آیا', 'کدام', 'معنی', 'تعریف', 'چیست', ' چیست', 'کیست',
        'چیکار', 'چطوری', 'راهنمایی', 'کمک', 'چجوری', 'چند',
        'کی', 'کجاست', 'چگونه', 'چرا', 'چه وقت', 'چه زمانی'
    ]
    
    # بررسی نشانه‌ها
    if any(indicator in text_lower for indicator in question_indicators):
        return True
    
    # اگر متن کوتاه باشد
    if len(text.split()) <= 5:
        return True
    
    return False

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    user = update.effective_user
    
    # ثبت فعالیت کاربر
    db.update_user_activity(
        user_id, 
        user.username, 
        user.first_name, 
        user.last_name
    )
    
    # بررسی محدودیت نرخ
    if not security_manager.check_rate_limit(user_id):
        await update.message.reply_text(
            "⏳ وای! یه کم سریع داری می‌فرستی! بذار ۱ دقیقه استراحت کنم 😅",
            reply_markup=main_keyboard
        )
        return
    
    # پاکسازی ورودی
    text = security_manager.sanitize_input(text)
    
    # ایجاد سشن اگر وجود ندارد
    if user_id not in user_sessions:
        user_sessions[user_id] = {'mode': 'ready'}
    
    current_mode = user_sessions[user_id].get('mode', 'ready')
    
    # بررسی لغو
    if text == "❌ لغو":
        user_sessions[user_id] = {'mode': 'ready'}
        await update.message.reply_text(
            "✅ اوکی! لغو شد. حالا چیکار می‌خوای بکنیم?",
            reply_markup=main_keyboard
        )
        return
    
    # بررسی پیام‌های عامیانه
    casual_key = is_casual_message(text)
    if casual_key and current_mode == 'ready':
        response = random.choice(casual_responses[casual_key])
        await update.message.reply_text(response, reply_markup=main_keyboard)
        return
    
    # مدیریت منو
    menu_actions = {
        "🤔 سوال بپرس": ('waiting_query', "🤔 حله! سوالت رو بپرس:"),
        "📚 خلاصه هوشمند": ('waiting_summary_query', "📚 اوکی! چه موضوعی رو می‌خوای خلاصه‌اش رو ببینی?"),
        "🌐 از سایت یاد بگیر": ('waiting_url', "🌐 آفرین! لینک سایت رو بفرست:"),
        "📁 موضوعات موجود": (None, categories_command),
        "💡 پیشنهادات هوشمند": (None, recommend_command),
        "📊 آمار و اطلاعات": (None, stats_command),
        "🎯 آموزش ربات": ('waiting_category', "🎯 حله! می‌خوای چی یادم بدی? اول دسته‌بندی رو بگو:"),
        "❓ راهنما": (None, help_command)
    }
    
    if text in menu_actions and current_mode == 'ready':
        action = menu_actions[text]
        if action[0] is not None:
            user_sessions[user_id] = {'mode': action[0]}
            await update.message.reply_text(
                action[1],
                reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
            )
        else:
            await action[1](update, context)
        return
    
    # مدیریت حالت‌های مختلف
    if current_mode == 'waiting_category':
        await handle_waiting_category(update, text)
    
    elif current_mode == 'waiting_topic':
        await handle_waiting_topic(update, text)
    
    elif current_mode == 'waiting_content':
        await handle_waiting_content(update, text)
    
    elif current_mode == 'waiting_query':
        await handle_question(update, text)
    
    elif current_mode == 'waiting_summary_query':
        await handle_summary(update, text)
    
    elif current_mode == 'waiting_url':
        await handle_website_url(update, text)
    
    elif current_mode == 'waiting_website_category':
        await handle_website_category(update, text)
    
    elif current_mode == 'waiting_file':
        await handle_file_upload(update, context)
    
    elif current_mode == 'waiting_file_category':
        await handle_file_category(update, text)
    
    # اگر در حالت عادی هستیم و متن شبیه سوال است
    elif current_mode == 'ready' and is_question(text):
        await handle_question(update, text)
    
    else:
        await update.message.reply_text(
            "🤔 وای! متوجه نشدم! می‌شه دوباره بگی?",
            reply_markup=main_keyboard
        )

async def handle_waiting_category(update: Update, category: str):
    """مدیریت دریافت دسته‌بندی"""
    user_id = update.effective_user.id
    user_sessions[user_id]['category'] = category
    user_sessions[user_id]['mode'] = 'waiting_topic'
    
    await update.message.reply_text(
        f"📁 حله! دسته‌بندی: {category}\n\nحالا موضوع یا عنوان رو بگو:"
    )

async def handle_waiting_topic(update: Update, topic: str):
    """مدیریت دریافت موضوع"""
    user_id = update.effective_user.id
    user_sessions[user_id]['topic'] = topic
    user_sessions[user_id]['mode'] = 'waiting_content'
    
    await update.message.reply_text(
        f"📝 عالی! موضوع: {topic}\n\nحالا محتوا یا اطلاعات رو برام بنویس:"
    )

async def handle_waiting_content(update: Update, content: str):
    """مدیریت دریافت محتوا"""
    user_id = update.effective_user.id
    category = user_sessions[user_id]['category']
    topic = user_sessions[user_id]['topic']
    
    # بررسی محدودیت طول محتوا
    if len(content) > 4000:
        await update.message.reply_text(
            "❌ وای! محتوا خیلی طولانیه! لطفاً زیر ۴۰۰۰ کاراکتر بنویس."
        )
        return
    
    success = db.save_knowledge(category, topic, content)
    
    if success:
        await update.message.reply_text(
            f"✅ **آفرین! اطلاعات ذخیره شد!**\n\n"
            f"📁 دسته: {category}\n"
            f"📝 موضوع: {topic}\n"
            f"📏 محتوا: {len(content)} کاراکتر\n\n"
            f"حالا می‌تونی با /ask ازم بپرسی! 🎯",
            reply_markup=main_keyboard,
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(
            "❌ وای! خطا در ذخیره اطلاعات!",
            reply_markup=main_keyboard
        )
    
    user_sessions[user_id] = {'mode': 'ready'}

async def handle_question(update: Update, question: str):
    """مدیریت سوالات"""
    user_id = update.effective_user.id
    
    print(f"🔍 کاربر {user_id} سوال پرسید: {question}")
    
    # ثبت تعامل کاربر
    db.save_user_interaction(user_id, question, 'question')
    recommendation_engine.record_interaction(user_id, question)
    
    await update.message.reply_text("🔍 در حال جستجو و تحقیق...")
    
    try:
        # استفاده از researcher برای پیدا کردن جواب
        research_result = researcher.research_topic(question)
        
        print(f"✅ نتیجه تحقیق: {research_result[:100]}...")
        
        # اگر تحقیق موفق بود، در دیتابیس ذخیره کن
        if research_result and not research_result.startswith("❌"):
            db.save_knowledge(
                category="تحقیق شده",
                topic=question,
                content=research_result,
                source_type="research",
                confidence=0.8
            )
        
        await update.message.reply_text(research_result, reply_markup=main_keyboard, parse_mode='Markdown')
        
    except Exception as e:
        print(f"❌ خطا در handle_question: {e}")
        await update.message.reply_text(
            "❌ متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
            reply_markup=main_keyboard
        )
    
    user_sessions[user_id] = {'mode': 'ready'}

async def handle_summary(update: Update, query: str):
    """مدیریت درخواست خلاصه"""
    user_id = update.effective_user.id
    
    await update.message.reply_text("📊 دارم اطلاعات رو جمع‌آوری می‌کنم...")
    
    # ایجاد خلاصه
    summary = summarizer.create_comprehensive_summary(query)
    
    await update.message.reply_text(
        summary,
        reply_markup=main_keyboard,
        parse_mode='Markdown'
    )
    
    user_sessions[user_id] = {'mode': 'ready'}

async def handle_website_url(update: Update, url: str):
    """مدیریت دریافت URL سایت"""
    user_id = update.effective_user.id
    
    # اعتبارسنجی URL
    if not url.startswith(('http://', 'https://')):
        await update.message.reply_text(
            "❌ وای! لینک باید با http یا https شروع بشه!",
            reply_markup=main_keyboard
        )
        user_sessions[user_id] = {'mode': 'ready'}
        return
    
    await update.message.reply_text("🌐 دارم به سایت وصل می‌شم...")
    
    # استخراج محتوا از سایت
    content = scraper.scrape_website(url)
    
    if content.startswith("❌"):
        await update.message.reply_text(content, reply_markup=main_keyboard)
        user_sessions[user_id] = {'mode': 'ready'}
        return
    
    user_sessions[user_id] = {
        'mode': 'waiting_website_category',
        'website_content': content,
        'website_url': url
    }
    
    # استخراج دامنه برای پیشنهاد
    domain = url.split('//')[-1].split('/')[0]
    
    await update.message.reply_text(
        f"✅ **آفرین! محتوای سایت دریافت شد!**\n\n"
        f"🌐 سایت: {domain}\n"
        f"📏 حجم: {len(content)} کاراکتر\n\n"
        f"📝 **پیش‌نمایش:**\n{content[:200]}...\n\n"
        f"لطفاً دسته‌بندی این محتوا رو وارد کن:",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def handle_website_category(update: Update, category: str):
    """مدیریت دریافت دسته‌بندی برای محتوای سایت"""
    user_id = update.effective_user.id
    content = user_sessions[user_id]['website_content']
    url = user_sessions[user_id]['website_url']
    
    domain = url.split('//')[-1].split('/')[0]
    
    success = db.save_knowledge(
        category=category,
        topic=f"محتوا از {domain}",
        content=content,
        source_type='website',
        source_url=url
    )
    
    if success:
        await update.message.reply_text(
            f"✅ **آفرین! اطلاعات از سایت ذخیره شد!**\n\n"
            f"🌐 سایت: {domain}\n"
            f"📁 دسته: {category}\n"
            f"📏 محتوا: {len(content)} کاراکتر\n\n"
            f"حالا می‌تونی در موردش سوال بپرسی! 💫",
            reply_markup=main_keyboard
        )
    else:
        await update.message.reply_text(
            "❌ وای! خطا در ذخیره اطلاعات از سایت!",
            reply_markup=main_keyboard
        )
    
    user_sessions[user_id] = {'mode': 'ready'}

async def handle_file_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مدیریت آپلود فایل"""
    user_id = update.effective_user.id
    
    if not update.message.document:
        await update.message.reply_text(
            "❌ وای! فایلی دریافت نکردم!",
            reply_markup=main_keyboard
        )
        return
    
    document = update.message.document
    file = await document.get_file()
    file_content = await file.download_as_bytearray()
    
    await update.message.reply_text("📄 دارم فایل رو بررسی می‌کنم...")
    
    # پردازش فایل
    file_name = document.file_name
    success, message, extracted_text = file_processor.process_file(file_content, file_name)
    
    if not success:
        await update.message.reply_text(message, reply_markup=main_keyboard)
        user_sessions[user_id] = {'mode': 'ready'}
        return
    
    user_sessions[user_id] = {
        'mode': 'waiting_file_category',
        'file_content': extracted_text,
        'file_name': file_name
    }
    
    await update.message.reply_text(
        f"✅ {message}\n\n"
        f"📝 **پیش‌نمایش:**\n{extracted_text[:200]}...\n\n"
        f"لطفاً دسته‌بندی این محتوا رو وارد کن:",
        reply_markup=ReplyKeyboardMarkup([["❌ لغو"]], resize_keyboard=True)
    )

async def handle_file_category(update: Update, category: str):
    """مدیریت دسته‌بندی فایل آپلود شده"""
    user_id = update.effective_user.id
    file_content = user_sessions[user_id]['file_content']
    file_name = user_sessions[user_id]['file_name']
    
    success = db.save_knowledge(
        category=category,
        topic=f"فایل: {file_name}",
        content=file_content,
        source_type='file_upload'
    )
    
    if success:
        await update.message.reply_text(
            f"✅ **آفرین! فایل با موفقیت ذخیره شد!**\n\n"
            f"📁 دسته: {category}\n"
            f"📄 فایل: {file_name}\n"
            f"📏 محتوا: {len(file_content)} کاراکتر\n\n"
            f"حالا می‌تونی در موردش سوال بپرسی! 💫",
            reply_markup=main_keyboard
        )
    else:
        await update.message.reply_text(
            "❌ وای! خطا در ذخیره فایل!",
            reply_markup=main_keyboard
        )
    
    user_sessions[user_id] = {'mode': 'ready'}

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مدیریت خطاها"""
    logger.error(f"خطا: {context.error}")
    
    if update and update.effective_message:
        await update.effective_message.reply_text(
            "❌ وای! یه مشکلی پیش اومده! لطفاً دوباره تلاش کن.",
            reply_markup=main_keyboard
        )

def main():
    # ایجاد اپلیکیشن
    application = Application.builder().token(BOT_TOKEN).build()
    
    # اضافه کردن هندلرها
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("learn", learn_command))
    application.add_handler(CommandHandler("ask", ask_command))
    application.add_handler(CommandHandler("summary", summary_command))
    application.add_handler(CommandHandler("website", website_command))
    application.add_handler(CommandHandler("upload", upload_command))
    application.add_handler(CommandHandler("recommend", recommend_command))
    application.add_handler(CommandHandler("categories", categories_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # هندلر فایل
    application.add_handler(MessageHandler(filters.Document.ALL, handle_file_upload))
    
    # هندلر خطا
    application.add_error_handler(error_handler)
    
    # تنظیم commands
    application.post_init = setup_commands
    
    print("🤖 **ربات دانش هوشمند با حالت خودمونی شروع به کار کرد!**")
    print("✅ **قابلیت‌های فعال:**")
    print("   - سیستم تحقیق هوشمند چندمنظوره")
    print("   - جستجوی پیشرفته در دیتابیس") 
    print("   - استخراج محتوا از وبسایت‌ها")
    print("   - خلاصه‌سازی ساختاریافته")
    print("   - پردازش فایل‌های مختلف")
    print("   - سیستم پیشنهاد هوشمند")
    print("   - پاسخ‌های خودمونی و صمیمی")
    print("   - مدیریت کاربران پیشرفته")
    print("   - کش‌سازی برای عملکرد بهتر")
    print("   - امنیت و محدودیت نرخ")
    print("\n🎯 **ربات با حال و هوای خودمونی آماده سرویس‌دهی است!**")
    
    # اجرای ربات
    application.run_polling(
        poll_interval=1,
        timeout=20,
        drop_pending_updates=True
    )

if __name__ == "__main__":
    main()