# config.py
BOT_TOKEN = "8275658185:AAHQHavsbELjUKrXcyIAmjm9FW5C247JzNc"
MAX_CONTENT_LENGTH = 4000
REQUEST_TIMEOUT = 10  # کاهش از 15 به 10 ثانیه

# تنظیمات جدید
REDIS_CONFIG = {
    'host': 'localhost',
    'port': 6379,
    'db': 0
}

NLP_CONFIG = {
    'model_name': "HooshvareLab/bert-base-parsbert-uncased",
    'similarity_threshold': 0.7
}

SECURITY_CONFIG = {
    'max_requests_per_minute': 20,  # افزایش محدودیت
    'max_file_size': 10 * 1024 * 1024,
    'allowed_file_types': ['pdf', 'docx', 'doc', 'jpg', 'jpeg', 'png', 'txt']
}

CACHE_CONFIG = {
    'default_expire_hours': 24,
    'search_cache_hours': 6,
    'user_session_hours': 2
}

# تنظیمات جدید برای بهبود عملکرد شبکه
NETWORK_CONFIG = {
    'max_retries': 2,
    'backoff_factor': 0.5,
    'timeout': 10
}