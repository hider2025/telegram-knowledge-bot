# security_manager.py
import time
import re
from datetime import datetime, timedelta
from collections import defaultdict
import hashlib
import random

class SecurityManager:
    def __init__(self):
        self.rate_limits = defaultdict(list)
        self.suspicious_activities = defaultdict(list)
        self.blocked_users = set()
        
        # الگوهای مخرب
        self.malicious_patterns = [
            r'<script.*?>.*?</script>',  # تگ‌های اسکریپت
            r'javascript:',              # جاوااسکریپت
            r'on\w+\s*=',               # event handlers
            r'<iframe.*?>.*?</iframe>',  # iframe
            r'<object.*?>.*?</object>',  # object
            r'<embed.*?>.*?</embed>',    # embed
            r'eval\s*\(',               # eval
            r'exec\s*\(',               # exec
            r'union\s+select',          # SQL injection
            r'drop\s+table',            # SQL injection
            r'insert\s+into',           # SQL injection
            r'select.*?from',           # SQL injection
            r'waitfor\s+delay',         # SQL injection
            r'shutdown',                 # خطرناک
            r'rm\s+-rf',                # خطرناک
            r'\.\./',                   # path traversal
        ]
        
        # کلمات کلیدی مخرب
        self.malicious_keywords = [
            'script', 'javascript', 'eval', 'exec', 'union', 'select',
            'drop', 'table', 'insert', 'delete', 'update', 'shutdown',
            'rm -rf', '../', '<!--', '-->', '<!DOCTYPE'
        ]
    
    def check_rate_limit(self, user_id: int, max_requests: int = 15, time_window: int = 60) -> bool:
        """بررسی محدودیت نرخ درخواست"""
        user_key = str(user_id)
        now = time.time()
        
        # اگر کاربر بلاک شده باشد
        if user_id in self.blocked_users:
            return False
        
        # حذف درخواست‌های قدیمی
        self.rate_limits[user_key] = [
            req_time for req_time in self.rate_limits[user_key] 
            if now - req_time < time_window
        ]
        
        # بررسی تعداد درخواست‌ها
        if len(self.rate_limits[user_key]) >= max_requests:
            # ثبت فعالیت مشکوک
            self._record_suspicious_activity(user_id, "rate_limit_exceeded")
            
            # اگر بیش از ۳ بار محدودیت را رد کرد، بلاک کن
            recent_violations = [
                activity for activity in self.suspicious_activities[user_id]
                if activity['type'] == 'rate_limit_exceeded' and 
                now - activity['timestamp'] < 3600  # 1 hour
            ]
            
            if len(recent_violations) >= 3:
                self.blocked_users.add(user_id)
            
            return False
        
        # ثبت درخواست جدید
        self.rate_limits[user_key].append(now)
        return True
    
    def sanitize_input(self, text: str, max_length: int = 4000) -> str:
        """پاکسازی ورودی کاربر"""
        if not text:
            return ""
        
        # حذف تگ‌های HTML و اسکریپت‌ها
        for pattern in self.malicious_patterns:
            text = re.sub(pattern, '', text, flags=re.IGNORECASE)
        
        # حذف کاراکترهای کنترل
        text = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
        
        # حذف فضاهای اضافی
        text = re.sub(r'\s+', ' ', text).strip()
        
        # محدودیت طول
        if len(text) > max_length:
            text = text[:max_length]
        
        return text
    
    def is_malicious_content(self, text: str) -> bool:
        """تشخیص محتوای مخرب"""
        if not text:
            return False
        
        text_lower = text.lower()
        
        # بررسی الگوهای مخرب
        for pattern in self.malicious_patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        
        # بررسی کلمات کلیدی مخرب
        for keyword in self.malicious_keywords:
            if keyword in text_lower:
                return True
        
        return False
    
    def validate_url(self, url: str) -> bool:
        """اعتبارسنجی URL"""
        if not url.startswith(('http://', 'https://')):
            return False
        
        # بررسی دامنه‌های مشکوک
        suspicious_domains = [
            'example.com', 'test.com', 'localhost', '127.0.0.1',
            'malicious.com', 'spam.com', 'phishing.com'
        ]
        
        for domain in suspicious_domains:
            if domain in url:
                return False
        
        return True
    
    def validate_file_upload(self, file_name: str, file_size: int, max_size: int = 10 * 1024 * 1024) -> bool:
        """اعتبارسنجی فایل آپلود شده"""
        # بررسی اندازه فایل
        if file_size > max_size:
            return False
        
        # بررسی پسوند فایل
        allowed_extensions = ['.pdf', '.docx', '.doc', '.txt', '.jpg', '.jpeg', '.png', '.bmp']
        file_ext = '.' + file_name.lower().split('.')[-1] if '.' in file_name else ''
        
        if file_ext not in allowed_extensions:
            return False
        
        # بررسی نام فایل
        if re.search(r'[<>:"/\\|?*]', file_name):
            return False
        
        return True
    
    def _record_suspicious_activity(self, user_id: int, activity_type: str):
        """ثبت فعالیت مشکوک"""
        activity = {
            'type': activity_type,
            'timestamp': time.time(),
            'user_id': user_id
        }
        
        self.suspicious_activities[user_id].append(activity)
        
        # محدود کردن تاریخچه به ۵۰ مورد اخیر
        if len(self.suspicious_activities[user_id]) > 50:
            self.suspicious_activities[user_id] = self.suspicious_activities[user_id][-50:]
    
    def get_security_status(self, user_id: int) -> dict:
        """دریافت وضعیت امنیتی کاربر"""
        user_key = str(user_id)
        
        now = time.time()
        recent_requests = [
            req_time for req_time in self.rate_limits[user_key] 
            if now - req_time < 60
        ]
        
        recent_suspicious = [
            activity for activity in self.suspicious_activities[user_id]
            if now - activity['timestamp'] < 3600  # 1 hour
        ]
        
        return {
            'is_blocked': user_id in self.blocked_users,
            'requests_last_minute': len(recent_requests),
            'suspicious_activities_last_hour': len(recent_suspicious),
            'rate_limit_remaining': max(0, 15 - len(recent_requests)),
            'security_level': self._calculate_security_level(user_id)
        }
    
    def _calculate_security_level(self, user_id: int) -> str:
        """محاسبه سطح امنیتی کاربر"""
        status = self.get_security_status(user_id)
        
        if status['is_blocked']:
            return "blocked"
        elif status['suspicious_activities_last_hour'] > 2:
            return "high_risk"
        elif status['suspicious_activities_last_hour'] > 0:
            return "medium_risk"
        else:
            return "low_risk"
    
    def unblock_user(self, user_id: int) -> bool:
        """آزاد کردن کاربر از بلاک"""
        if user_id in self.blocked_users:
            self.blocked_users.remove(user_id)
            return True
        return False
    
    def get_security_report(self) -> dict:
        """دریافت گزارش امنیتی"""
        now = time.time()
        
        total_users = len(self.rate_limits)
        blocked_users = len(self.blocked_users)
        
        recent_suspicious = 0
        for activities in self.suspicious_activities.values():
            recent_suspicious += len([
                act for act in activities 
                if now - act['timestamp'] < 3600
            ])
        
        return {
            'total_tracked_users': total_users,
            'blocked_users': blocked_users,
            'recent_suspicious_activities': recent_suspicious,
            'active_rate_limits': len([
                user for user, requests in self.rate_limits.items()
                if requests and now - requests[-1] < 300  # 5 minutes
            ])
        }

class CasualSecurityManager(SecurityManager):
    """مدیریت امنیت با پیام‌های خودمونی"""
    
    def get_friendly_security_message(self, user_id: int) -> str:
        """دریافت پیام امنیتی خودمونی"""
        status = self.get_security_status(user_id)
        
        if status['is_blocked']:
            return random.choice([
                "❌ وای! حساب شما موقتاً محدود شده! لطفاً با پشتیبانی تماس بگیرید.",
                "❌ اوف! دسترسی شما محدود شده! برای اطلاعات بیشتر پیام بدهید.",
                "❌ شرمنده! شما در لیست محدود شده‌ها هستید!"
            ])
        
        elif status['security_level'] == "high_risk":
            return random.choice([
                "⚠️ یه کم آروم‌تر عزیزم! داره سیستم قاطی می‌کنه!",
                "⚠️ وای! یه کم سریع داری کار می‌کنی! استراحت بده!",
                "⚠️ اوف! سیستم داره گرم می‌شه! یه کم صبر کن!"
            ])
        
        elif status['rate_limit_remaining'] < 5:
            return random.choice([
                f"💫 فقط {status['rate_limit_remaining']} درخواست دیگه می‌تونی بفرستی!",
                f"🎯 {status['rate_limit_remaining']} درخواست مونده! یه کم آروم‌تر!",
                f"🌈 حواست باشه! {status['rate_limit_remaining']} درخواست باقی‌مونده!"
            ])
        
        else:
            return random.choice([
                "✅ همه چی اوکیه! می‌تونی راحت کار کنی!",
                "💚 امنیت سیستم عالیه! ادامه بده!",
                "🎯 سیستم کاملاً امنه! بی‌محابا کار کن!"
            ])