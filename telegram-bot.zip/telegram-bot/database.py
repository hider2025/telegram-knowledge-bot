import sqlite3
import re
from datetime import datetime
import json

class KnowledgeDB:
    def __init__(self):
        self.init_database()
    
    def init_database(self):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                topic TEXT NOT NULL,
                content TEXT NOT NULL,
                source_type TEXT DEFAULT 'manual',
                source_url TEXT,
                tags TEXT,
                usage_count INTEGER DEFAULT 0,
                confidence_score REAL DEFAULT 1.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # جدول جدید برای کاربران
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                usage_count INTEGER DEFAULT 0,
                favorite_categories TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # جدول جدید برای تعاملات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                query TEXT,
                response_type TEXT,
                satisfaction_score INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # ایجاد ایندکس‌های جدید
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_topic ON knowledge(topic)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_category ON knowledge(category)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_search ON knowledge(topic, content)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_usage ON knowledge(usage_count)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user ON users(user_id)')
        
        conn.commit()
        conn.close()
    
    def save_knowledge(self, category, topic, content, source_type='manual', source_url=None, tags=None, confidence=1.0):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        # بررسی وجود رکورد تکراری با الگوریتم پیشرفته‌تر
        cursor.execute('''
            SELECT id, content FROM knowledge 
            WHERE topic = ? AND category = ?
        ''', (topic, category))
        
        existing = cursor.fetchone()
        
        if existing:
            # اگر محتوا متفاوت است، آپدیت کن
            if content != existing[1]:
                cursor.execute('''
                    UPDATE knowledge 
                    SET content = ?, source_url = ?, tags = ?, updated_at = CURRENT_TIMESTAMP,
                        confidence_score = ?
                    WHERE id = ?
                ''', (content, source_url, tags, confidence, existing[0]))
        else:
            # درج رکورد جدید
            cursor.execute('''
                INSERT INTO knowledge (category, topic, content, source_type, source_url, tags, confidence_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (category, topic, content, source_type, source_url, tags, confidence))
        
        conn.commit()
        conn.close()
        return True
    
    def search_knowledge(self, query, category=None, limit=5, use_semantic=False):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        if use_semantic and category:
            # جستجوی معنایی پیشرفته
            cursor.execute('''
                SELECT *, 
                       (CASE WHEN topic LIKE ? THEN 4 ELSE 0 END) +
                       (CASE WHEN content LIKE ? THEN 2 ELSE 0 END) +
                       (CASE WHEN tags LIKE ? THEN 1 ELSE 0 END) +
                       (confidence_score * 2) as relevance
                FROM knowledge 
                WHERE category = ?
                ORDER BY relevance DESC, usage_count DESC, updated_at DESC
                LIMIT ?
            ''', (f'%{query}%', f'%{query}%', f'%{query}%', category, limit))
        elif use_semantic:
            cursor.execute('''
                SELECT *, 
                       (CASE WHEN topic LIKE ? THEN 4 ELSE 0 END) +
                       (CASE WHEN content LIKE ? THEN 2 ELSE 0 END) +
                       (CASE WHEN tags LIKE ? THEN 1 ELSE 0 END) +
                       (confidence_score * 2) as relevance
                FROM knowledge 
                ORDER BY relevance DESC, usage_count DESC, updated_at DESC
                LIMIT ?
            ''', (f'%{query}%', f'%{query}%', f'%{query}%', limit))
        elif category:
            cursor.execute('''
                SELECT *, 
                       (CASE WHEN topic LIKE ? THEN 3 ELSE 0 END) +
                       (CASE WHEN content LIKE ? THEN 2 ELSE 0 END) +
                       (CASE WHEN tags LIKE ? THEN 1 ELSE 0 END) as relevance
                FROM knowledge 
                WHERE category = ?
                ORDER BY relevance DESC, usage_count DESC, updated_at DESC
                LIMIT ?
            ''', (f'%{query}%', f'%{query}%', f'%{query}%', category, limit))
        else:
            cursor.execute('''
                SELECT *, 
                       (CASE WHEN topic LIKE ? THEN 3 ELSE 0 END) +
                       (CASE WHEN content LIKE ? THEN 2 ELSE 0 END) +
                       (CASE WHEN tags LIKE ? THEN 1 ELSE 0 END) as relevance
                FROM knowledge 
                ORDER BY relevance DESC, usage_count DESC, updated_at DESC
                LIMIT ?
            ''', (f'%{query}%', f'%{query}%', f'%{query}%', limit))
        
        results = cursor.fetchall()
        
        # افزایش usage_count
        if results:
            ids = [str(result[0]) for result in results]
            id_placeholders = ','.join(['?'] * len(ids))
            cursor.execute(f'''
                UPDATE knowledge 
                SET usage_count = usage_count + 1 
                WHERE id IN ({id_placeholders})
            ''', ids)
            conn.commit()
        
        conn.close()
        return results
    
    def get_categories(self):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT category, COUNT(*) as count 
            FROM knowledge 
            GROUP BY category 
            ORDER BY count DESC, category
        ''')
        
        categories = [f"{row[0]} ({row[1]})" for row in cursor.fetchall()]
        conn.close()
        return categories
    
    def get_popular_topics(self, limit=10):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT topic, category, usage_count 
            FROM knowledge 
            ORDER BY usage_count DESC 
            LIMIT ?
        ''', (limit,))
        
        results = cursor.fetchall()
        conn.close()
        return results
    
    def get_stats(self):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM knowledge')
        total_records = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT category) FROM knowledge')
        total_categories = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT topic) FROM knowledge')
        total_topics = cursor.fetchone()[0]
        
        cursor.execute('SELECT SUM(usage_count) FROM knowledge')
        total_usage = cursor.fetchone()[0] or 0
        
        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_records': total_records,
            'total_categories': total_categories,
            'total_topics': total_topics,
            'total_usage': total_usage,
            'total_users': total_users
        }
    
    def save_user_interaction(self, user_id, query, response_type, satisfaction=None):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO interactions (user_id, query, response_type, satisfaction_score)
            VALUES (?, ?, ?, ?)
        ''', (user_id, query, response_type, satisfaction))
        
        conn.commit()
        conn.close()
    
    def update_user_activity(self, user_id, username=None, first_name=None, last_name=None):
        conn = sqlite3.connect('knowledge.db', check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO users (user_id, username, first_name, last_name, last_active, usage_count)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, COALESCE((SELECT usage_count + 1 FROM users WHERE user_id = ?), 1))
        ''', (user_id, username, first_name, last_name, user_id))
        
        conn.commit()
        conn.close()