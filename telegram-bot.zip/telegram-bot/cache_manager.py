# cache_manager.py
import sqlite3
import pickle
import hashlib
from datetime import datetime, timedelta
from typing import Any, Optional, Dict
import os

class CacheManager:
    def __init__(self, db_path: str = "cache.db"):
        self.db_path = db_path
        self.init_cache_db()
    
    def init_cache_db(self):
        """ایجاد دیتابیس کش"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY,
                value BLOB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                access_count INTEGER DEFAULT 0
            )
        ''')
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_access ON cache(access_count)')
        
        conn.commit()
        conn.close()
        
        # پاکسازی کش‌های منقضی شده
        self.clean_expired_cache()
    
    def _generate_key(self, data: Any) -> str:
        """تولید کلید یکتا برای داده"""
        if isinstance(data, str):
            data_str = data
        else:
            data_str = str(data)
        
        return hashlib.md5(data_str.encode('utf-8')).hexdigest()
    
    def set(self, key: str, value: Any, expire_hours: int = 24) -> bool:
        """ذخیره داده در کش"""
        try:
            cache_key = self._generate_key(key)
            expires_at = datetime.now() + timedelta(hours=expire_hours)
            
            # سریالایز کردن مقدار
            serialized_value = pickle.dumps(value)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO cache (key, value, expires_at, access_count)
                VALUES (?, ?, ?, COALESCE((SELECT access_count + 1 FROM cache WHERE key = ?), 1))
            ''', (cache_key, serialized_value, expires_at, cache_key))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"خطا در ذخیره کش: {e}")
            return False
    
    def get(self, key: str) -> Optional[Any]:
        """دریافت داده از کش"""
        try:
            cache_key = self._generate_key(key)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT value, expires_at FROM cache 
                WHERE key = ? AND (expires_at IS NULL OR expires_at > ?)
            ''', (cache_key, datetime.now()))
            
            result = cursor.fetchone()
            
            if result:
                # افزایش شماره دسترسی
                cursor.execute('UPDATE cache SET access_count = access_count + 1 WHERE key = ?', (cache_key,))
                conn.commit()
                
                value = pickle.loads(result[0])
                conn.close()
                return value
            
            conn.close()
            return None
            
        except Exception as e:
            print(f"خطا در خواندن کش: {e}")
            return None
    
    def delete(self, key: str) -> bool:
        """حذف داده از کش"""
        try:
            cache_key = self._generate_key(key)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM cache WHERE key = ?', (cache_key,))
            conn.commit()
            conn.close()
            
            return cursor.rowcount > 0
            
        except Exception as e:
            print(f"خطا در حذف کش: {e}")
            return False
    
    def clean_expired_cache(self) -> int:
        """پاکسازی کش‌های منقضی شده"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM cache WHERE expires_at < ?', (datetime.now(),))
            deleted_count = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            print(f"✅ {deleted_count} کش منقضی شده پاکسازی شد")
            return deleted_count
            
        except Exception as e:
            print(f"خطا در پاکسازی کش: {e}")
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """دریافت آمار کش"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('SELECT COUNT(*) FROM cache')
            total_items = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM cache WHERE expires_at < ?', (datetime.now(),))
            expired_items = cursor.fetchone()[0]
            
            cursor.execute('SELECT SUM(access_count) FROM cache')
            total_access = cursor.fetchone()[0] or 0
            
            cursor.execute('SELECT key, access_count FROM cache ORDER BY access_count DESC LIMIT 5')
            popular_items = [{"key": row[0], "access_count": row[1]} for row in cursor.fetchall()]
            
            conn.close()
            
            return {
                "total_items": total_items,
                "expired_items": expired_items,
                "total_access": total_access,
                "popular_items": popular_items
            }
            
        except Exception as e:
            print(f"خطا در دریافت آمار کش: {e}")
            return {}
    
    def clear_all(self) -> bool:
        """پاکسازی تمام کش"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM cache')
            conn.commit()
            conn.close()
            
            print("✅ تمام کش‌ها پاکسازی شدند")
            return True
            
        except Exception as e:
            print(f"خطا در پاکسازی کامل کش: {e}")
            return False