# scraper.py
import requests
import re
from bs4 import BeautifulSoup
from config import REQUEST_TIMEOUT
from security_manager import SecurityManager
import random
from urllib.parse import urlparse
import time

class WebsiteScraper:
    def __init__(self):
        self.security = SecurityManager()
        self.session = requests.Session()
        self.setup_session()
    
    def setup_session(self):
        """تنظیم session برای درخواست‌ها"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        self.session.headers.update(headers)
    
    def scrape_website(self, url: str) -> str:
        """
        استخراج محتوای اصلی از وبسایت با مدیریت خطا و پاسخ‌های خودمونی
        """
        try:
            # اعتبارسنجی URL
            if not self.security.validate_url(url):
                return random.choice([
                    "❌ وای! این لینک معتبر به نظر نمی‌رسه!",
                    "❌ اوف! این آدرس سایت درست نیست!",
                    "❌ شرمنده! این لینک رو نمی‌تونم باز کنم!"
                ])
            
            # بررسی دامنه‌های مجاز
            if not self._is_allowed_domain(url):
                return random.choice([
                    "❌ وای! این نوع سایت رو نمی‌تونم بررسی کنم!",
                    "❌ اوف! این دامنه رو پشتیبانی نمی‌کنم!",
                    "❌ شرمنده! از این سایت نمی‌تونم محتوا بگیرم!"
                ])
            
            # دریافت محتوا
            response = self.session.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            
            # بررسی نوع محتوا
            content_type = response.headers.get('content-type', '')
            if 'text/html' not in content_type:
                return random.choice([
                    "❌ وای! این لینک یه فایل هست، نه یه صفحه وب!",
                    "❌ اوف! این آدرس به یه فایل اشاره می‌کنه!",
                    "❌ شرمنده! این لینک محتوای متنی نداره!"
                ])
            
            # پارس کردن HTML
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # استخراج محتوای اصلی
            content = self._extract_main_content(soup)
            
            if not content or len(content.strip()) < 100:
                return random.choice([
                    "❌ وای! نتونستم محتوای اصلی رو از این صفحه پیدا کنم!",
                    "❌ اوف! این صفحه محتوای قابل خواندی نداره!",
                    "❌ شرمنده! محتوای مناسبی توی این سایت پیدا نکردم!"
                ])
            
            # پاکسازی نهایی
            clean_content = self._clean_extracted_content(content)
            
            if len(clean_content) < 50:
                return random.choice([
                    "❌ وای! محتوای استخراج شده خیلی کوتاهه!",
                    "❌ اوف! متن سایت خیلی کم بود!",
                    "❌ شرمنده! محتوای کافی برای ذخیره کردن نداریم!"
                ])
            
            success_messages = [
                f"✅ آفرین! محتوای سایت رو با موفقیت استخراج کردم! 📚\n\n📏 حجم متن: {len(clean_content)} کاراکتر",
                f"✅ عالی بود! متن سایت رو گرفتم! 🌐\n\n📏 اندازه محتوا: {len(clean_content)} کاراکتر",
                f"✅ حله! محتوای وبسایت رو استخراج کردم! 💫\n\n📏 تعداد کاراکتر: {len(clean_content)}"
            ]
            
            return f"{random.choice(success_messages)}\n\n📖 پیش‌نمایش:\n{clean_content[:300]}..."
            
        except requests.exceptions.Timeout:
            return random.choice([
                "❌ وای! زمان اتصال به سایت تموم شد!",
                "❌ اوف! سایت خیلی دیر جواب داد!",
                "❌ شرمنده! نتونستم به سایت وصل بشم!"
            ])
        except requests.exceptions.HTTPError as e:
            return random.choice([
                f"❌ وای! سایت خطا داد: {e.response.status_code}",
                f"❌ اوف! مشکل در دسترسی به سایت: {e.response.status_code}",
                f"❌ شرمنده! سایت در دسترس نیست: {e.response.status_code}"
            ])
        except requests.exceptions.RequestException as e:
            return random.choice([
                f"❌ وای! خطا در اتصال به سایت: {str(e)}",
                f"❌ اوف! مشکل شبکه: {str(e)}",
                f"❌ شرمنده! خطای ارتباطی: {str(e)}"
            ])
        except Exception as e:
            return random.choice([
                f"❌ وای! خطای ناشناخته: {str(e)}",
                f"❌ اوف! یه مشکل فنی پیش اومد: {str(e)}",
                f"❌ شرمنده! خطا در استخراج محتوا: {str(e)}"
            ])
    
    def _is_allowed_domain(self, url: str) -> bool:
        """بررسی مجاز بودن دامنه"""
        try:
            parsed_url = urlparse(url)
            domain = parsed_url.netloc.lower()
            
            # دامنه‌های مجاز
            allowed_domains = [
                'wikipedia.org', 'fa.wikipedia.org', 'en.wikipedia.org',
                'britannica.com', 'healthline.com', 'webmd.com',
                'stackoverflow.com', 'github.com', 'medium.com',
                'bbc.com', 'cnn.com', 'reuters.com'
            ]
            
            # دامنه‌های ممنوع
            blocked_domains = [
                'facebook.com', 'twitter.com', 'instagram.com',
                'youtube.com', 'tiktok.com', 'porn', 'adult',
                'localhost', '127.0.0.1', '192.168.', '10.'
            ]
            
            # بررسی دامنه‌های ممنوع
            for blocked in blocked_domains:
                if blocked in domain:
                    return False
            
            # اگر دامنه در لیست مجاز نیست، باز هم اجازه بده اما با احتیاط
            return True
            
        except:
            return False
    
    def _extract_main_content(self, soup: BeautifulSoup) -> str:
        """استخراج محتوای اصلی از صفحه"""
        # حذف المان‌های غیرضروری
        for element in soup(["script", "style", "nav", "header", "footer", "aside", "form", "button", "iframe"]):
            element.decompose()
        
        # الویت‌بندی المنت‌های محتوا
        content_selectors = [
            'article',
            'main',
            '[role="main"]',
            '.content',
            '.post-content',
            '.article-content',
            '.entry-content',
            '.story-body',
            '.news-content',
            '.blog-content',
            '#content',
            '#main-content',
            '.main-content',
            '.post',
            '.article',
            '.story'
        ]
        
        for selector in content_selectors:
            elements = soup.select(selector)
            for element in elements:
                text = element.get_text().strip()
                if len(text) > 200 and self._is_valid_content(text):
                    return text
        
        # اگر المنت خاصی پیدا نشد، از تگ main استفاده کن
        main_element = soup.find('main')
        if main_element:
            text = main_element.get_text().strip()
            if len(text) > 200 and self._is_valid_content(text):
                return text
        
        # از تگ article استفاده کن
        article_element = soup.find('article')
        if article_element:
            text = article_element.get_text().strip()
            if len(text) > 200 and self._is_valid_content(text):
                return text
        
        # در نهایت از پاراگراف‌ها استفاده کن
        return self._extract_from_paragraphs(soup)
    
    def _extract_from_paragraphs(self, soup: BeautifulSoup) -> str:
        """استخراج محتوا از پاراگراف‌ها"""
        paragraphs = soup.find_all('p')
        content_text = ''
        
        for p in paragraphs:
            text = p.get_text().strip()
            if len(text) > 50 and self._is_valid_content(text):
                content_text += text + '\n\n'
            if len(content_text) > 2000:  # حداکثر ۲۰۰۰ کاراکتر از پاراگراف‌ها
                break
        
        return content_text
    
    def _is_valid_content(self, text: str) -> bool:
        """بررسی معتبر بودن محتوا"""
        if not text or len(text.strip()) < 50:
            return False
        
        # فیلتر محتوای بی‌ربط
        invalid_indicators = [
            'cookie', 'privacy', 'terms', 'login', 'sign up', 'register',
            'subscribe', 'newsletter', 'advertisement', 'ads', 'sponsored',
            'menu', 'navigation', 'sidebar', 'footer', 'header', 'breadcrumb',
            'copyright', 'all rights reserved', 'follow us', 'share this'
        ]
        
        text_lower = text.lower()
        for indicator in invalid_indicators:
            if indicator in text_lower:
                return False
        
        # بررسی نسبت حروف فارسی/انگلیسی
        persian_chars = len(re.findall(r'[آ-ی]', text))
        english_chars = len(re.findall(r'[a-zA-Z]', text))
        total_chars = len(re.findall(r'\w', text))
        
        if total_chars == 0:
            return False
        
        # اگر متن فارسی است (بیش از ۲۰٪ حروف فارسی)
        if persian_chars / total_chars > 0.2:
            return True
        
        # اگر متن انگلیسی است (بیش از ۴۰٪ حروف انگلیسی و طول کافی)
        if english_chars / total_chars > 0.4 and len(text) > 100:
            return True
        
        return False
    
    def _clean_extracted_content(self, text: str) -> str:
        """پاکسازی محتوای استخراج شده"""
        # حذف فضاهای اضافی
        text = re.sub(r'\s+', ' ', text)
        
        # حذف خطوط کوتاه و بی‌معنی
        lines = [line.strip() for line in text.split('\n') if len(line.strip()) > 20]
        
        # حذف متن‌های تکراری
        unique_lines = []
        for line in lines:
            if line not in unique_lines and len(line) > 10:
                unique_lines.append(line)
        
        # محدودیت حجم نهایی
        cleaned_text = '\n'.join(unique_lines[:20])  # حداکثر ۲۰ خط
        return cleaned_text[:3500]  # محدودیت نهایی ۳۵۰۰ کاراکتر
    
    def get_site_info(self, url: str) -> dict:
        """دریافت اطلاعات کلی درباره سایت"""
        try:
            response = self.session.head(url, timeout=10)
            parsed_url = urlparse(url)
            
            return {
                'domain': parsed_url.netloc,
                'status_code': response.status_code,
                'content_type': response.headers.get('content-type', ''),
                'server': response.headers.get('server', ''),
                'is_accessible': response.status_code == 200
            }
        except:
            return {'domain': urlparse(url).netloc, 'is_accessible': False}

class SmartScraper(WebsiteScraper):
    """اسکراپر هوشمند با قابلیت‌های پیشرفته"""
    
    def scrape_with_analysis(self, url: str) -> dict:
        """استخراج محتوا همراه با تحلیل"""
        content = self.scrape_website(url)
        site_info = self.get_site_info(url)
        
        if content.startswith("❌"):
            return {
                'success': False,
                'content': content,
                'site_info': site_info
            }
        
        # تحلیل محتوا
        analysis = self._analyze_content(content)
        
        return {
            'success': True,
            'content': content,
            'site_info': site_info,
            'analysis': analysis
        }
    
    def _analyze_content(self, content: str) -> dict:
        """تحلیل محتوای استخراج شده"""
        words = content.split()
        sentences = [s.strip() for s in content.split('.') if s.strip()]
        
        # تشخیص زبان
        persian_chars = sum(1 for char in content if '\u0600' <= char <= '\u06FF')
        english_chars = sum(1 for char in content if 'a' <= char.lower() <= 'z')
        
        if persian_chars > english_chars:
            language = "فارسی"
        elif english_chars > persian_chars:
            language = "انگلیسی"
        else:
            language = "ترکیبی"
        
        return {
            'word_count': len(words),
            'sentence_count': len(sentences),
            'language': language,
            'reading_time_minutes': max(1, len(words) // 200),
            'has_questions': any('?' in s or '؟' in s for s in sentences),
            'content_preview': content[:200] + "..." if len(content) > 200 else content
        }