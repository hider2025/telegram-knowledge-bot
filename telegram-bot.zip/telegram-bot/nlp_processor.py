# nlp_processor.py
import requests
import json
import random
from typing import List, Dict, Tuple

class PersianNLP:
    def __init__(self):
        self.casual_patterns = self._load_casual_patterns()
        self.question_patterns = self._load_question_patterns()
    
    def _load_casual_patterns(self) -> Dict[str, List[str]]:
        """الگوهای مکالمات خودمونی"""
        return {
            'greeting': [
                "سلام {}! چطوری قشنگم؟ 💫",
                "درود به {}! چه خبر خوبی؟ 🌈",
                "سلام {} جون! چیکار میکنی؟ 😊",
                "سلام به {}! امروز چه حالی داری؟ 💖"
            ],
            'thanks': [
                "خواهش می‌کنم {}! 💝",
                "قربونت {} عزیزم! 😍",
                "کاری نکردم {} جون! 🤗",
                "چیزیش نیس {} قشنگم! 💫"
            ],
            'farewell': [
                "خداحافظ {}! موفق باشی 🌟",
                "بای بای {}! 👋",
                "خداحافظ {} عزیزم! 💫",
                "بای {}! همیشه شاد باشی 💖"
            ],
            'encouragement': [
                "آفرین {}! دمت گرم 🎯",
                "چه باحال {}! ادامه بده 💫",
                "عالی {}! همینطور پیش برو 🚀",
                "آفرین {}! خیلی باهوشی 💡"
            ]
        }
    
    def _load_question_patterns(self) -> Dict[str, List[str]]:
        """الگوهای تشخیص سوال"""
        return {
            'definition': [' چیست', ' چیست', ' چه چیزی', ' معنی', ' تعریف', ' یعنی چه'],
            'how_to': [' چگونه', ' چطور', ' چجوری', ' روش', ' راهنمایی', ' چطوری'],
            'why': [' چرا', ' دلیل', ' علت', ' به چه دلیل'],
            'comparison': [' مقایسه', ' فرق', ' تفاوت', ' بهتر', ' مقایسه'],
            'temporal': [' کی', ' چه زمانی', ' چه وقت', ' تاریخ', ' کِی'],
            'quantity': [' چند', ' چقدر', ' چه مقدار', ' چه تعداد'],
            'location': [' کجا', ' کجاست', ' کدام شهر', ' کدام کشور'],
            'person': [' کیست', ' چه کسی', ' چه کسایی', ' چه کسانی']
        }
    
    def detect_question_type(self, text: str) -> str:
        """تشخیص نوع سوال"""
        text_lower = text.lower()
        
        for q_type, patterns in self.question_patterns.items():
            if any(pattern in text_lower for pattern in patterns):
                return q_type
        
        return 'general'
    
    def generate_casual_response(self, response_type: str, user_name: str = "عزیزم") -> str:
        """تولید پاسخ خودمونی"""
        if response_type in self.casual_patterns:
            return random.choice(self.casual_patterns[response_type]).format(user_name)
        return "ممنون از تو! 💫"
    
    def extract_keywords(self, text: str) -> List[str]:
        """استخراج کلمات کلیدی از متن"""
        # حذف کلمات اضافه
        stop_words = {'است', 'های', 'را', 'که', 'به', 'با', 'این', 'آن', 'برای', 'از'}
        words = text.split()
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        return keywords[:5]  # حداکثر ۵ کلمه کلیدی
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """محاسبه شباهت بین دو متن (ساده)"""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
    
    def is_casual_conversation(self, text: str) -> bool:
        """تشخیص مکالمات غیررسمی"""
        casual_phrases = [
            'سلام', 'خوبی', 'چطوری', 'ممنون', 'مرسی', 'خداحافظ', 
            'بای', 'شب بخیر', 'صبح بخیر', 'دوستت دارم', 'حالت چطوره',
            'اسمت چیه', 'چند سالته', 'کی ساختت', 'چکار میکنی'
        ]
        
        text_lower = text.lower()
        return any(phrase in text_lower for phrase in casual_phrases)
    
    def enhance_response_tone(self, response: str, tone: str = "friendly") -> str:
        """بهبود لحن پاسخ"""
        if tone == "friendly":
            enhancements = [
                "💫 راستی، ",
                "🎯 نکته جالبش اینه که ",
                "💡 یه چیز باحال دیگه هم بگم: ",
                "🌟 می‌دونی چه چیز جالبی داره؟ ",
                "😊 راستی فراموش نکن که "
            ]
            if random.random() > 0.7:  # 30% chance
                response = random.choice(enhancements) + response.lower()
        
        return response
    
    def detect_user_mood(self, text: str) -> str:
        """تشخیص حال و هوای کاربر (ساده)"""
        positive_words = ['ممنون', 'مرسی', 'عالی', 'خوب', 'عالیه', 'زیبا', 'قشنگ', 'دوستت دارم']
        negative_words = ['بد', 'ضعیف', 'ضعیفه', 'بیخیال', 'نداریم', 'نیست']
        
        text_lower = text.lower()
        
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"

class AdvancedPersianNLP(PersianNLP):
    """نسخه پیشرفته‌تر با قابلیت‌های بیشتر"""
    
    def __init__(self):
        super().__init__()
        self.sentiment_lexicon = self._load_sentiment_lexicon()
    
    def _load_sentiment_lexicon(self) -> Dict[str, float]:
        """لود لغت‌نامه احساسات فارسی"""
        # این می‌تواند از یک فایل خارجی لود شود
        return {
            'عالی': 1.0, 'خوب': 0.8, 'زیبا': 0.9, 'قشنگ': 0.8, 'ممنون': 0.7,
            'بد': -0.8, 'ضعیف': -0.7, 'بیخیال': -0.6, 'نداریم': -0.5,
            'خوشحال': 0.9, 'شاد': 0.8, 'ناراحت': -0.7, 'غمگین': -0.8
        }
    
    def analyze_sentiment(self, text: str) -> float:
        """تحلیل احساسات متن"""
        words = text.split()
        sentiment_score = 0.0
        matched_words = 0
        
        for word in words:
            if word in self.sentiment_lexicon:
                sentiment_score += self.sentiment_lexicon[word]
                matched_words += 1
        
        if matched_words > 0:
            return sentiment_score / matched_words
        return 0.0
    
    def generate_empathetic_response(self, text: str, user_name: str = "عزیزم") -> str:
        """تولید پاسخ همدلانه"""
        sentiment = self.analyze_sentiment(text)
        
        if sentiment > 0.3:
            responses = [
                f"چه عالی {user_name}! خوشحالم که حالت خوبه! 💖",
                f"آفرین {user_name}! انرژی مثبتت رو دوست دارم! 🌈",
                f"عالی {user_name}! همینطور پرانرژی باش! 🚀"
            ]
        elif sentiment < -0.3:
            responses = [
                f"اوه {user_name}!\nامیدوارم حالت بهتر بشه! 💫",
                f"می‌بینم یه کم ناراحتی {user_name}!\nاینجا هستم برات! 🤗",
                f"اشکال نداره {user_name}!\nهمه چی درست میشه! 🌸"
            ]
        else:
            responses = [
                f"متشکرم {user_name}! 💫",
                f"قربونت {user_name}! 😊",
                f"ممنون {user_name} جون! 💝"
            ]
        
        return random.choice(responses)